/* fonts */
export const FontFamily = {
  kumbhSansLight: "KumbhSans-Light",
  kumbhSansMedium: "KumbhSans-Medium",
  comfortaaLight: "Comfortaa-Light",
  kumbhSansRegular: "KumbhSans-Regular",
  comfortaaRegular: "Comfortaa-Regular",
  kumbhSansBold: "KumbhSans-Bold",
  kumbhSansBlack: "KumbhSans-Black",
};
/* font sizes */
export const FontSize = {
  size_xl: 20,
  size_base: 16,
  size_21xl: 40,
  size_5xl: 24,
  size_13xl: 32,
  size_mini: 15,
  size_36xl: 55,
  size_24xl: 43,
  size_29xl: 48,
  size_smi: 13,
  size_14xl: 33,
  size_lgi: 19,
  size_2xs: 11,
  size_xs: 12,
  size_3xs: 10,
  size_8xl: 27,
  size_sm: 14,
  size_5xs: 8,
  size_lg: 18,
  size_4xl: 23,
};
/* Colors */
export const Color = {
  colorGray: "#0d0d0d",
  colorDarkslategray_100: "#35402f",
  colorDarkslategray_200: "rgba(53, 64, 47, 0.8)",
  colorGainsboro_100: "#eae8e8",
  colorGainsboro_200: "#d9d9d9",
  colorWhite: "#fff",
  colorLightgray: "#c3cfb7",
  colorBlack: "#000",
  colorDarkolivegreen_100: "#586b4d",
  colorDarkolivegreen_200: "#395922",
  colorDarkolivegreen_300: "rgba(57, 89, 34, 0.9)",
  colorDarkseagreen: "#b4d99a",
};
/* Paddings */
export const Padding = {
  p_sm: 14,
  p_21xl: 40,
  p_2xs: 11,
  p_6xs: 7,
  p_5xs: 8,
};
/* border radiuses */
export const Border = {
  br_12xl: 31,
  br_20xl: 39,
  br_lgi: 19,
  br_9xs_5: 4,
  br_10xl_5: 30,
  br_27xl_5: 47,
  br_mini: 15,
  br_base: 16,
  br_18xl: 37,
};
