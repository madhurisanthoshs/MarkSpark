import * as React from "react";
import { FontSize } from "../GlobalStyles";

const CreditValue = () => {
  return (
    <Text style={styles.text}>{`108.5/150
`}</Text>
  );
};

const styles = StyleSheet.create({
  text: {
    fontSize: FontSize.size_24xl,
  },
});

export default CreditValue;
