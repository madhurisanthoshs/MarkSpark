import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import {
  TextInput as RNPTextInput,
  Button as RNPButton,
} from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import { Border, FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

const LoginErrorMessages = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.loginErrorMessages, styles.frameFlexBox]}>
      <View style={styles.frame1}>
        <View style={[styles.frame2, styles.frameFlexBox]}>
          <Text style={styles.loginMessage} numberOfLines={2}>
            <Text style={styles.login}>{`Login
`}</Text>
            <Text style={styles.usingYourVtop}>
              Using your VTOP credentials
            </Text>
          </Text>
        </View>
        <RNPTextInput
          style={[styles.usernameBox, styles.boxShadowBox]}
          label="VTOP Username"
          placeholder="Username"
          mode="flat"
          placeholderTextColor="#c3cfb7"
          theme={{
            fonts: {
              regular: { fontFamily: "Kumbh Sans", fontWeight: "Light" },
            },
            colors: { text: "#c3cfb7" },
          }}
        />
        <RNPButton
          style={[styles.frame3, styles.frameFlexBox]}
          mode="outlined"
          labelStyle={styles.frame2Btn}
          onPress={() => navigation.navigate("LoginCaptcha")}
          contentStyle={styles.frame2Btn1}
        >
          Sign in
        </RNPButton>
        <View style={[styles.frame4, styles.frameFlexBox]}>
          <RNPTextInput
            style={[styles.passwordBox, styles.boxShadowBox]}
            label="VTOP Password"
            placeholder="Password"
            mode="outlined"
            placeholderTextColor="#c3cfb7"
            theme={{
              fonts: {
                regular: { fontFamily: "Kumbh Sans", fontWeight: "Light" },
              },
              colors: { text: "#c3cfb7", background: "#35402f" },
            }}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frame2Btn: {
    color: "#b4d99a",
    fontSize: 24,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  frame2Btn1: {
    width: 182,
  },
  frameFlexBox: {
    justifyContent: "center",
    overflow: "hidden",
  },
  boxShadowBox: {
    flexDirection: "row",
    height: 62,
    width: 330,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_12xl,
    alignItems: "center",
  },
  login: {
    fontSize: FontSize.size_21xl,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
  },
  usingYourVtop: {
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.kumbhSansLight,
    fontWeight: "300",
  },
  loginMessage: {
    color: Color.colorGainsboro_100,
    textAlign: "left",
    width: 249,
    height: 78,
  },
  frame2: {
    top: 0,
    left: 12,
    width: 308,
    position: "absolute",
  },
  usernameBox: {
    top: 157,
    left: 1,
    backgroundColor: Color.colorDarkslategray_100,
    borderColor: Color.colorBlack,
    borderWidth: 1,
    paddingLeft: Padding.p_2xs,
    paddingTop: Padding.p_6xs,
    paddingBottom: Padding.p_6xs,
    position: "absolute",
  },
  frame3: {
    top: 410,
    left: 75,
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
  },
  passwordBox: {
    paddingLeft: 10,
    paddingTop: Padding.p_5xs,
    paddingRight: 1,
    paddingBottom: Padding.p_5xs,
  },
  frame4: {
    top: 238,
    left: 0,
    width: 332,
    alignItems: "flex-end",
    position: "absolute",
  },
  frame1: {
    alignSelf: "stretch",
    height: 472,
    marginTop: 79,
    overflow: "hidden",
  },
  loginErrorMessages: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    paddingHorizontal: Padding.p_sm,
    paddingVertical: Padding.p_21xl,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default LoginErrorMessages;
