import * as React from "react";
import { Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const CalculatedGPA = () => {
  return <Text style={styles.text}>9.67</Text>;
};

const styles = StyleSheet.create({
  text: {
    position: "absolute",
    top: 558,
    left: 46,
    fontSize: FontSize.size_21xl,
    letterSpacing: 0.4,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
    color: Color.colorDarkseagreen,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 270,
    height: 48,
  },
});

export default CalculatedGPA;
