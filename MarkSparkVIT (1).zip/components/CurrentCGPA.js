import * as React from "react";
import { FontSize } from "../GlobalStyles";

const CurrentCGPA = () => {
  return (
    <Text style={styles.text}>{`8.70
`}</Text>
  );
};

const styles = StyleSheet.create({
  text: {
    fontSize: FontSize.size_36xl,
  },
});

export default CurrentCGPA;
