import * as React from "react";
import { Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const CreditsEarned = () => {
  return <Text style={styles.text}>103.5/ 103.5</Text>;
};

const styles = StyleSheet.create({
  text: {
    position: "absolute",
    top: 201,
    left: 250,
    fontSize: FontSize.size_mini,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
    color: Color.colorDarkseagreen,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 46,
    height: 38,
  },
});

export default CreditsEarned;
