import * as React from "react";
import { FontSize, FontFamily } from "../GlobalStyles";

const CurrCGPA = () => {
  return (
    <Text style={styles.text}>{`8.70
`}</Text>
  );
};

const styles = StyleSheet.create({
  text: {
    fontSize: FontSize.size_14xl,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
  },
});

export default CurrCGPA;
