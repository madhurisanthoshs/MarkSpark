import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet } from "react-native";

const Graph = () => {
  return (
    <Image
      style={styles.graphIcon}
      contentFit="cover"
      source={require("../assets/graph.png")}
    />
  );
};

const styles = StyleSheet.create({
  graphIcon: {
    position: "absolute",
    top: 239,
    left: 18,
    width: 321,
    height: 321,
  },
});

export default Graph;
