import * as React from "react";
import { StyleSheet, View } from "react-native";
import { Border, Color } from "../GlobalStyles";

const GraphGPA = () => {
  return <View style={styles.graphChild} />;
};

const styles = StyleSheet.create({
  graphChild: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: Border.br_18xl,
    backgroundColor: Color.colorGainsboro_200,
    width: 321,
    height: 321,
  },
});

export default GraphGPA;
