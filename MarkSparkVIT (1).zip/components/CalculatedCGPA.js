import * as React from "react";
import { Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const CalculatedCGPA = () => {
  return <Text style={styles.text}>8.78</Text>;
};

const styles = StyleSheet.create({
  text: {
    position: "absolute",
    top: 508,
    left: 45,
    fontSize: FontSize.size_21xl,
    letterSpacing: 0.4,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
    color: Color.colorDarkseagreen,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 270,
    height: 48,
  },
});

export default CalculatedCGPA;
