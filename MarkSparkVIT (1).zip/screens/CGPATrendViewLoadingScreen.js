import React, { useState } from "react";
import { StyleSheet, View, Text } from "react-native";
import { ActivityIndicator } from "react-native-paper";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const CGPATrendViewLoadingScreen = () => {
  const [
    loadingScreenActivityIndicatorAnimating,
    setLoadingScreenActivityIndicatorAnimating,
  ] = useState(true);

  return (
    <View style={styles.cgpaTrendViewLoadingScreen}>
      <View
        style={[styles.cgpaTrendViewLoadingScreenChild, styles.loadingPosition]}
      />
      <View
        style={[styles.cgpaTrendViewLoadingScreen1, styles.calculatingLayout]}
      >
        <ActivityIndicator
          style={[styles.loadingScreen, styles.loadingPosition]}
          animating={loadingScreenActivityIndicatorAnimating}
          size="[object Object]"
          color="#939393"
        />
        <Text style={[styles.calculating, styles.calculatingLayout]}>
          Calculating...
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  loadingPosition: {
    top: 0,
    position: "absolute",
  },
  calculatingLayout: {
    width: 195,
    position: "absolute",
  },
  cgpaTrendViewLoadingScreenChild: {
    backgroundColor: Color.colorDarkslategray_100,
    width: 360,
    left: 0,
    height: 800,
  },
  loadingScreen: {
    left: 63,
    width: 69,
    height: 65,
  },
  calculating: {
    top: 98,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.kumbhSansRegular,
    color: Color.colorLightgray,
    textAlign: "center",
    height: 61,
    left: 0,
  },
  cgpaTrendViewLoadingScreen1: {
    top: 320,
    left: 82,
    height: 159,
  },
  cgpaTrendViewLoadingScreen: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default CGPATrendViewLoadingScreen;
