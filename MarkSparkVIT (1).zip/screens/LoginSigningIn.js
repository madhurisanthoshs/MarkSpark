import React, { useState } from "react";
import { StyleSheet, View, Text } from "react-native";
import { ActivityIndicator } from "react-native-paper";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const LoginSigningIn = () => {
  const [
    loadingIconActivityIndicatorAnimating,
    setLoadingIconActivityIndicatorAnimating,
  ] = useState(true);

  return (
    <View style={styles.loginSigningIn}>
      <View style={styles.overlay} />
      <View style={styles.signInMessage}>
        <ActivityIndicator
          style={styles.loadingIcon}
          animating={loadingIconActivityIndicatorAnimating}
          size="[object Object]"
          color="#939393"
        />
        <Text style={styles.signInMessage1} numberOfLines={1}>
          Signing you in...
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  overlay: {
    top: 0,
    left: 0,
    backgroundColor: Color.colorDarkslategray_100,
    width: 360,
    position: "absolute",
    height: 800,
  },
  loadingIcon: {
    width: 69,
    height: 65,
    alignSelf: "center",
  },
  signInMessage1: {
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.kumbhSansRegular,
    color: Color.colorLightgray,
    textAlign: "center",
    height: 61,
    marginTop: 33,
    width: 195,
  },
  signInMessage: {
    top: 321,
    left: 83,
    height: 159,
    alignItems: "center",
    justifyContent: "center",
    width: 195,
    position: "absolute",
  },
  loginSigningIn: {
    backgroundColor: Color.colorBlack,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default LoginSigningIn;
