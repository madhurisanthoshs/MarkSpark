import React, { useState } from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import DropDownPicker from "react-native-dropdown-picker";
import { useNavigation } from "@react-navigation/native";
import CalculatedGPA from "../components/CalculatedGPA";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const GPACalculatedGPA = () => {
  const [gradeOpen, setGradeOpen] = useState(false);
  const [gradeValue, setGradeValue] = useState();
  const [gradeItems, setGradeItems] = useState([
    { value: "S", label: "S" },
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
    { value: "F", label: "F" },
  ]);
  const [creditOpen, setCreditOpen] = useState(false);
  const [creditValue, setCreditValue] = useState();
  const [creditItems, setCreditItems] = useState([
    { value: "1", label: "1" },
    { value: "1.5", label: "1.5" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
  ]);
  const [grade1Open, setGrade1Open] = useState(false);
  const [grade1Value, setGrade1Value] = useState();
  const [grade1Items, setGrade1Items] = useState([
    { value: "S", label: "S" },
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
    { value: "F", label: "F" },
  ]);
  const [credit1Open, setCredit1Open] = useState(false);
  const [credit1Value, setCredit1Value] = useState();
  const [credit1Items, setCredit1Items] = useState([
    { value: "1", label: "1" },
    { value: "1.5", label: "1.5" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
  ]);
  const [grade2Open, setGrade2Open] = useState(false);
  const [grade2Value, setGrade2Value] = useState();
  const [grade2Items, setGrade2Items] = useState([
    { value: "S", label: "S" },
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
    { value: "F", label: "F" },
  ]);
  const [credit2Open, setCredit2Open] = useState(false);
  const [credit2Value, setCredit2Value] = useState();
  const [credit2Items, setCredit2Items] = useState([
    { value: "1", label: "1" },
    { value: "1.5", label: "1.5" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
  ]);
  const [grade3Open, setGrade3Open] = useState(false);
  const [grade3Value, setGrade3Value] = useState();
  const [grade3Items, setGrade3Items] = useState([
    { value: "S", label: "S" },
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
    { value: "F", label: "F" },
  ]);
  const [credit3Open, setCredit3Open] = useState(false);
  const [credit3Value, setCredit3Value] = useState();
  const [credit3Items, setCredit3Items] = useState([
    { value: "1", label: "1" },
    { value: "1.5", label: "1.5" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
  ]);
  const [grade4Open, setGrade4Open] = useState(false);
  const [grade4Value, setGrade4Value] = useState();
  const [grade4Items, setGrade4Items] = useState([
    { value: "S", label: "S" },
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
    { value: "F", label: "F" },
  ]);
  const [credit4Open, setCredit4Open] = useState(false);
  const [credit4Value, setCredit4Value] = useState();
  const [credit4Items, setCredit4Items] = useState([
    { value: "1", label: "1" },
    { value: "1.5", label: "1.5" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
  ]);
  const [grade5Open, setGrade5Open] = useState(false);
  const [grade5Value, setGrade5Value] = useState();
  const [grade5Items, setGrade5Items] = useState([
    { value: "S", label: "S" },
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
    { value: "F", label: "F" },
  ]);
  const [credit5Open, setCredit5Open] = useState(false);
  const [credit5Value, setCredit5Value] = useState();
  const [credit5Items, setCredit5Items] = useState([
    { value: "1", label: "1" },
    { value: "1.5", label: "1.5" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
  ]);
  const [grade6Open, setGrade6Open] = useState(false);
  const [grade6Value, setGrade6Value] = useState();
  const [grade6Items, setGrade6Items] = useState([
    { value: "S", label: "S" },
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
    { value: "F", label: "F" },
  ]);
  const [credit6Open, setCredit6Open] = useState(false);
  const [credit6Value, setCredit6Value] = useState();
  const [credit6Items, setCredit6Items] = useState([
    { value: "1", label: "1" },
    { value: "1.5", label: "1.5" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
  ]);
  const [grade7Open, setGrade7Open] = useState(false);
  const [grade7Value, setGrade7Value] = useState();
  const [grade7Items, setGrade7Items] = useState([
    { value: "S", label: "S" },
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
    { value: "F", label: "F" },
  ]);
  const [credit7Open, setCredit7Open] = useState(false);
  const [credit7Value, setCredit7Value] = useState();
  const [credit7Items, setCredit7Items] = useState([
    { value: "1", label: "1" },
    { value: "1.5", label: "1.5" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
  ]);
  const navigation = useNavigation();

  return (
    <View style={styles.gpaCalculatedGpa}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <View style={[styles.gpaCalculatedGpaChild, styles.gpaLayout]} />
      <View style={[styles.gpaCalculatedGpaItem, styles.gpaLayout]} />
      <View style={[styles.gpaCalculatedGpaInner, styles.gpaLayout]} />
      <Text style={styles.gpaPredictor}>GPA predictor</Text>
      <View style={[styles.rectangleView, styles.gpaShadowBox]} />
      <Text style={styles.submit}>Submit</Text>
      <View style={styles.gpaCalculatedGpaChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <View style={styles.gpaCalculatedGpaChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={[styles.gpaCalculatedGpaChild3, styles.gpaChildLayout1]} />
      <View style={[styles.gpaCalculatedGpaChild4, styles.gpaChildPosition7]} />
      <View style={[styles.gpaCalculatedGpaChild5, styles.gpaChildPosition6]} />
      <View style={[styles.gpaCalculatedGpaChild6, styles.gpaChildPosition5]} />
      <View style={[styles.gpaCalculatedGpaChild7, styles.gpaChildPosition4]} />
      <View style={[styles.gpaCalculatedGpaChild8, styles.gpaChildPosition3]} />
      <View style={[styles.gpaCalculatedGpaChild9, styles.gpaChildPosition2]} />
      <View style={[styles.gpaCalculatedGpaChild10, styles.gpaChildLayout1]} />
      <View
        style={[styles.gpaCalculatedGpaChild11, styles.gpaChildPosition7]}
      />
      <View
        style={[styles.gpaCalculatedGpaChild12, styles.gpaChildPosition6]}
      />
      <View
        style={[styles.gpaCalculatedGpaChild13, styles.gpaChildPosition5]}
      />
      <View
        style={[styles.gpaCalculatedGpaChild14, styles.gpaChildPosition4]}
      />
      <View
        style={[styles.gpaCalculatedGpaChild15, styles.gpaChildPosition3]}
      />
      <View
        style={[styles.gpaCalculatedGpaChild16, styles.gpaChildPosition2]}
      />
      <Text style={[styles.grade, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.lineIcon, styles.gpaChildLayout]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaCalculatedGpaChild17, styles.gpaChildPosition1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade1, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit1, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.gpaCalculatedGpaChild18, styles.gpaChildLayout]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaCalculatedGpaChild19, styles.gpaChildPosition1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade2, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit2, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.gpaCalculatedGpaChild20, styles.gpaChildLayout]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaCalculatedGpaChild21, styles.gpaChildPosition1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade3, styles.grade3Typo]}>Grade</Text>
      <Text style={[styles.credit3, styles.grade3Typo]}>Credit</Text>
      <Image
        style={[styles.gpaCalculatedGpaChild22, styles.gpaChildLayout]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaCalculatedGpaChild23, styles.gpaChildPosition1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade4, styles.grade4Typo]}>Grade</Text>
      <Text style={[styles.credit4, styles.grade4Typo]}>Credit</Text>
      <Image
        style={[styles.gpaCalculatedGpaChild24, styles.gpaChildLayout]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaCalculatedGpaChild25, styles.gpaChildPosition1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade5, styles.grade5Typo]}>Grade</Text>
      <Text style={[styles.credit5, styles.grade5Typo]}>Credit</Text>
      <Image
        style={[styles.gpaCalculatedGpaChild26, styles.gpaChildLayout]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaCalculatedGpaChild27, styles.gpaChildPosition1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade6, styles.grade6Typo]}>Grade</Text>
      <Text style={[styles.credit6, styles.grade6Typo]}>Credit</Text>
      <Image
        style={[styles.gpaCalculatedGpaChild28, styles.gpaChildLayout]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaCalculatedGpaChild29, styles.gpaChildPosition1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.frameIcon}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <Text style={styles.gpaPredictor}>GPA predictor</Text>
      <View style={[styles.gpaCalculatedGpaChild30, styles.gpaShadowBox]} />
      <Button
        title="Submit"
        radius={5}
        iconPosition="left"
        type="solid"
        titleStyle={styles.submitButtonBtn}
        onPress={() => navigation.navigate("GPALoadingScreen")}
        containerStyle={styles.submitButtonBtn1}
        buttonStyle={styles.submitButtonBtn2}
      />
      <View style={styles.gpaCalculatedGpaChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <View style={styles.gpaCalculatedGpaChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <View style={[styles.grade7, styles.gradeLayout]}>
        <DropDownPicker
          open={gradeOpen}
          setOpen={setGradeOpen}
          value={gradeValue}
          setValue={setGradeValue}
          placeholder="Grade"
          items={gradeItems}
          labelStyle={styles.gradeValue}
          textStyle={styles.gradeText}
        />
      </View>
      <View style={[styles.credit7, styles.creditLayout]}>
        <DropDownPicker
          open={creditOpen}
          setOpen={setCreditOpen}
          value={creditValue}
          setValue={setCreditValue}
          placeholder="Credit"
          items={creditItems}
          labelStyle={styles.creditValue}
          textStyle={styles.creditText}
        />
      </View>
      <View style={[styles.grade8, styles.gradeLayout]}>
        <DropDownPicker
          open={grade1Open}
          setOpen={setGrade1Open}
          value={grade1Value}
          setValue={setGrade1Value}
          placeholder="Grade"
          items={grade1Items}
          labelStyle={styles.grade1Value}
          textStyle={styles.grade1Text}
        />
      </View>
      <View style={[styles.credit8, styles.creditLayout]}>
        <DropDownPicker
          open={credit1Open}
          setOpen={setCredit1Open}
          value={credit1Value}
          setValue={setCredit1Value}
          placeholder="Credit"
          items={credit1Items}
          labelStyle={styles.credit1Value}
          textStyle={styles.credit1Text}
        />
      </View>
      <View style={[styles.grade9, styles.gradeLayout]}>
        <DropDownPicker
          open={grade2Open}
          setOpen={setGrade2Open}
          value={grade2Value}
          setValue={setGrade2Value}
          placeholder="Grade"
          items={grade2Items}
          labelStyle={styles.grade2Value}
          textStyle={styles.grade2Text}
        />
      </View>
      <View style={[styles.credit9, styles.creditLayout]}>
        <DropDownPicker
          open={credit2Open}
          setOpen={setCredit2Open}
          value={credit2Value}
          setValue={setCredit2Value}
          placeholder="Credit"
          items={credit2Items}
          labelStyle={styles.credit2Value}
          textStyle={styles.credit2Text}
        />
      </View>
      <View style={[styles.grade10, styles.gradeLayout]}>
        <DropDownPicker
          open={grade3Open}
          setOpen={setGrade3Open}
          value={grade3Value}
          setValue={setGrade3Value}
          placeholder="Grade"
          items={grade3Items}
          labelStyle={styles.grade3Value}
          textStyle={styles.grade3Text}
        />
      </View>
      <View style={[styles.credit10, styles.creditLayout]}>
        <DropDownPicker
          open={credit3Open}
          setOpen={setCredit3Open}
          value={credit3Value}
          setValue={setCredit3Value}
          placeholder="Credit"
          items={credit3Items}
          labelStyle={styles.credit3Value}
          textStyle={styles.credit3Text}
        />
      </View>
      <View style={[styles.grade11, styles.gradeLayout]}>
        <DropDownPicker
          open={grade4Open}
          setOpen={setGrade4Open}
          value={grade4Value}
          setValue={setGrade4Value}
          placeholder="Grade"
          items={grade4Items}
          labelStyle={styles.grade4Value}
          textStyle={styles.grade4Text}
        />
      </View>
      <View style={[styles.credit11, styles.creditLayout]}>
        <DropDownPicker
          open={credit4Open}
          setOpen={setCredit4Open}
          value={credit4Value}
          setValue={setCredit4Value}
          placeholder="Credit"
          items={credit4Items}
          labelStyle={styles.credit4Value}
          textStyle={styles.credit4Text}
        />
      </View>
      <View style={[styles.grade12, styles.gradeLayout]}>
        <DropDownPicker
          open={grade5Open}
          setOpen={setGrade5Open}
          value={grade5Value}
          setValue={setGrade5Value}
          placeholder="Grade"
          items={grade5Items}
          labelStyle={styles.grade5Value}
          textStyle={styles.grade5Text}
        />
      </View>
      <View style={[styles.credit12, styles.creditLayout]}>
        <DropDownPicker
          open={credit5Open}
          setOpen={setCredit5Open}
          value={credit5Value}
          setValue={setCredit5Value}
          placeholder="Credit"
          items={credit5Items}
          labelStyle={styles.credit5Value}
          textStyle={styles.credit5Text}
        />
      </View>
      <View style={[styles.grade13, styles.gradeLayout]}>
        <DropDownPicker
          open={grade6Open}
          setOpen={setGrade6Open}
          value={grade6Value}
          setValue={setGrade6Value}
          placeholder="Grade"
          items={grade6Items}
          labelStyle={styles.grade6Value}
          textStyle={styles.grade6Text}
        />
      </View>
      <View style={[styles.credit13, styles.creditLayout]}>
        <DropDownPicker
          open={credit6Open}
          setOpen={setCredit6Open}
          value={credit6Value}
          setValue={setCredit6Value}
          placeholder="Credit"
          items={credit6Items}
          labelStyle={styles.credit6Value}
          textStyle={styles.credit6Text}
        />
      </View>
      <View style={[styles.gpaCalculatedGpaChild33, styles.gpaChildPosition]} />
      <View style={[styles.gpaCalculatedGpaChild34, styles.gpaChildPosition]} />
      <Text style={[styles.grade14, styles.grade14Typo]}>Grade</Text>
      <Text style={[styles.credit14, styles.grade14Typo]}>Credit</Text>
      <Image
        style={[styles.gpaCalculatedGpaChild35, styles.gpaChildLayout]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaCalculatedGpaChild36, styles.gpaChildPosition1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <View style={[styles.grade15, styles.gpaChildPosition]}>
        <DropDownPicker
          open={grade7Open}
          setOpen={setGrade7Open}
          value={grade7Value}
          setValue={setGrade7Value}
          placeholder="Grade"
          items={grade7Items}
          labelStyle={styles.grade7Value}
          textStyle={styles.grade7Text}
        />
      </View>
      <View style={[styles.credit15, styles.gpaChildPosition]}>
        <DropDownPicker
          open={credit7Open}
          setOpen={setCredit7Open}
          value={credit7Value}
          setValue={setCredit7Value}
          placeholder="Credit"
          items={credit7Items}
          labelStyle={styles.credit7Value}
          textStyle={styles.credit7Text}
        />
      </View>
      <View style={styles.gpaCalculatedGpaChild37} />
      <CalculatedGPA />
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        onPress={() => navigation.navigate("GPAMainScreen")}
        containerStyle={styles.lineIcon16Btn}
        buttonStyle={styles.lineIcon16Btn1}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  submitButtonBtn: {
    color: "#b4d99a",
    fontSize: 24,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  submitButtonBtn1: {
    left: 124,
    top: 640,
    position: "absolute",
  },
  submitButtonBtn2: {
    width: 113,
    height: 48,
    backgroundColor: "#395922",
  },
  gradeValue: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  gradeText: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  creditValue: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  creditText: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade1Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade1Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit1Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit1Text: {
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade2Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade2Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit2Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit2Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade3Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade3Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit3Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit3Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade4Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade4Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit4Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit4Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade5Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade5Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit5Value: {
    color: "#35420f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit5Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade6Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade6Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit6Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit6Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade7Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  grade7Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit7Value: {
    color: "#35402f",
    fontSize: 14,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  credit7Text: {
    color: "#35402f",
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  lineIcon16Btn: {
    left: 18,
    top: 24,
    position: "absolute",
  },
  lineIcon16Btn1: {
    borderStyle: "solid",
    width: 11,
    height: 18,
    backgroundColor: "#C3CFB7",
  },
  gpaLayout: {
    height: 2,
    width: 31,
    borderTopWidth: 2,
    borderColor: Color.colorGainsboro_100,
    borderStyle: "solid",
    left: 309,
    position: "absolute",
  },
  gpaShadowBox: {
    borderWidth: 1,
    borderColor: Color.colorBlack,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkolivegreen_200,
    borderStyle: "solid",
    position: "absolute",
  },
  gpaTypo: {
    height: 34,
    width: 78,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
    fontSize: FontSize.size_mini,
    top: 766,
    justifyContent: "center",
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout2: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  gpaChildLayout1: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
  },
  gpaChildPosition7: {
    height: 38,
    top: 177,
    position: "absolute",
  },
  gpaChildPosition6: {
    top: 227,
    height: 39,
    position: "absolute",
  },
  gpaChildPosition5: {
    top: 278,
    height: 38,
    position: "absolute",
  },
  gpaChildPosition4: {
    top: 328,
    height: 39,
    position: "absolute",
  },
  gpaChildPosition3: {
    top: 379,
    height: 38,
    position: "absolute",
  },
  gpaChildPosition2: {
    top: 429,
    height: 39,
    position: "absolute",
  },
  gradeTypo: {
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  gpaChildLayout: {
    height: 13,
    width: 19,
    left: 130,
    position: "absolute",
  },
  gpaChildPosition1: {
    left: 284,
    height: 13,
    width: 19,
    position: "absolute",
  },
  grade3Typo: {
    top: 282,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  grade4Typo: {
    top: 333,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  grade5Typo: {
    top: 383,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  grade6Typo: {
    top: 433,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout: {
    flexDirection: "row",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  gradeLayout: {
    width: 147,
    left: 28,
  },
  creditLayout: {
    width: 143,
    left: 181,
  },
  gpaChildPosition: {
    top: 480,
    height: 39,
    position: "absolute",
  },
  grade14Typo: {
    top: 484,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  marksparkVit: {
    top: 23,
    left: 80,
    fontWeight: "300",
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  gpaCalculatedGpaChild: {
    top: 24,
  },
  gpaCalculatedGpaItem: {
    top: 32,
  },
  gpaCalculatedGpaInner: {
    top: 40,
  },
  gpaPredictor: {
    top: 71,
    left: 15,
    textAlign: "left",
    width: 204,
    height: 39,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  rectangleView: {
    top: 640,
    left: 124,
    borderRadius: Border.br_12xl,
    width: 113,
    height: 48,
  },
  submit: {
    top: 648,
    left: 139,
    fontSize: FontSize.size_5xl,
    color: Color.colorDarkseagreen,
    width: 84,
    height: 33,
    justifyContent: "center",
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  gpaCalculatedGpaChild1: {
    top: 710,
    left: 1,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    position: "absolute",
  },
  home: {
    left: 7,
  },
  grades: {
    left: 97,
  },
  gpa: {
    left: 187,
  },
  cgpa: {
    left: 277,
  },
  vectorIcon: {
    right: "80.83%",
    left: "6.39%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.67%",
    left: "57.5%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.67%",
    left: "82.22%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.28%",
    left: "31.11%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  gpaCalculatedGpaChild3: {
    left: 38,
    top: 126,
    height: 39,
    position: "absolute",
  },
  gpaCalculatedGpaChild4: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 38,
  },
  gpaCalculatedGpaChild5: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 38,
  },
  gpaCalculatedGpaChild6: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 38,
  },
  gpaCalculatedGpaChild7: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 38,
  },
  gpaCalculatedGpaChild8: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 38,
  },
  gpaCalculatedGpaChild9: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 38,
  },
  gpaCalculatedGpaChild10: {
    top: 126,
    height: 39,
    position: "absolute",
    left: 187,
  },
  gpaCalculatedGpaChild11: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 187,
  },
  gpaCalculatedGpaChild12: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 187,
  },
  gpaCalculatedGpaChild13: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 187,
  },
  gpaCalculatedGpaChild14: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 187,
  },
  gpaCalculatedGpaChild15: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 187,
  },
  gpaCalculatedGpaChild16: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 187,
  },
  grade: {
    top: 129,
    left: 28,
  },
  credit: {
    top: 130,
    left: 181,
  },
  lineIcon: {
    top: 138,
  },
  gpaCalculatedGpaChild17: {
    top: 140,
  },
  grade1: {
    top: 180,
    left: 28,
  },
  credit1: {
    top: 181,
    left: 181,
  },
  gpaCalculatedGpaChild18: {
    top: 189,
  },
  gpaCalculatedGpaChild19: {
    top: 191,
  },
  grade2: {
    top: 230,
    left: 28,
  },
  credit2: {
    top: 231,
    left: 181,
  },
  gpaCalculatedGpaChild20: {
    top: 239,
  },
  gpaCalculatedGpaChild21: {
    top: 241,
  },
  grade3: {
    left: 28,
  },
  credit3: {
    left: 181,
  },
  gpaCalculatedGpaChild22: {
    top: 291,
  },
  gpaCalculatedGpaChild23: {
    top: 292,
  },
  grade4: {
    left: 28,
  },
  credit4: {
    left: 181,
  },
  gpaCalculatedGpaChild24: {
    top: 342,
  },
  gpaCalculatedGpaChild25: {
    top: 343,
  },
  grade5: {
    left: 28,
  },
  credit5: {
    left: 181,
  },
  gpaCalculatedGpaChild26: {
    top: 392,
  },
  gpaCalculatedGpaChild27: {
    top: 393,
  },
  grade6: {
    left: 28,
  },
  credit6: {
    left: 181,
  },
  gpaCalculatedGpaChild28: {
    top: 442,
  },
  gpaCalculatedGpaChild29: {
    top: 443,
  },
  frameIcon: {
    top: 25,
    left: 310,
    width: 29,
    height: 16,
    position: "absolute",
  },
  gpaCalculatedGpaChild30: {
    top: 552,
    borderRadius: Border.br_mini,
    width: 286,
    height: 60,
    left: 38,
  },
  grade7: {
    top: 126,
    height: 39,
    position: "absolute",
  },
  credit7: {
    top: 126,
    height: 39,
    position: "absolute",
  },
  grade8: {
    height: 38,
    top: 177,
    position: "absolute",
  },
  credit8: {
    height: 38,
    top: 177,
    position: "absolute",
  },
  grade9: {
    top: 227,
    height: 39,
    position: "absolute",
  },
  credit9: {
    top: 227,
    height: 39,
    position: "absolute",
  },
  grade10: {
    top: 278,
    height: 38,
    position: "absolute",
  },
  credit10: {
    top: 278,
    height: 38,
    position: "absolute",
  },
  grade11: {
    top: 328,
    height: 39,
    position: "absolute",
  },
  credit11: {
    top: 328,
    height: 39,
    position: "absolute",
  },
  grade12: {
    top: 379,
    height: 38,
    position: "absolute",
  },
  credit12: {
    top: 379,
    height: 38,
    position: "absolute",
  },
  grade13: {
    top: 429,
    height: 39,
    position: "absolute",
  },
  credit13: {
    top: 429,
    height: 39,
    position: "absolute",
  },
  gpaCalculatedGpaChild33: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 38,
  },
  gpaCalculatedGpaChild34: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    left: 187,
  },
  grade14: {
    left: 28,
  },
  credit14: {
    left: 181,
  },
  gpaCalculatedGpaChild35: {
    top: 493,
  },
  gpaCalculatedGpaChild36: {
    top: 494,
  },
  grade15: {
    width: 147,
    left: 28,
  },
  credit15: {
    width: 143,
    left: 181,
  },
  gpaCalculatedGpaChild37: {
    top: 222,
    left: 341,
    borderRadius: Border.br_9xs_5,
    backgroundColor: Color.colorLightgray,
    width: 7,
    height: 242,
    position: "absolute",
  },
  gpaCalculatedGpa: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default GPACalculatedGPA;
