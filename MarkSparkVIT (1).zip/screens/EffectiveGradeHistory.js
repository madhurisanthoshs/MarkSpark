import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const EffectiveGradeHistory = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.effectiveGradeHistory}>
      <Text style={styles.effectiveGrades}>Effective Grades</Text>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.effectiveGradeHistoryChild}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <View
        style={[styles.effectiveGradeHistoryItem, styles.effectiveChildLayout]}
      />
      <Text
        style={[
          styles.bchy101lEngineeringChemistryContainer,
          styles.containerPosition8,
        ]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`BCHY101L 
`}</Text>
          <Text style={styles.engineeringChemistry}>Engineering Chemistry</Text>
        </Text>
      </Text>
      <Text
        style={[styles.creditsGrade30Container, styles.creditsContainerLayout]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`Credits         Grade
`}</Text>
          <Text style={styles.a}>3.0 A</Text>
        </Text>
      </Text>
      <View style={[styles.effectiveGradeHistoryInner, styles.loPosition]} />
      <Text
        style={[
          styles.bcse102pStructuredAndContainer,
          styles.containerPosition7,
        ]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`BCSE102P
`}</Text>
          <Text style={styles.engineeringChemistry}>
            Structured and Object-Oriented Programming Lab
          </Text>
        </Text>
      </Text>
      <Text style={[styles.creditsGrade20Container, styles.containerPosition7]}>
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`Credits         Grade
`}</Text>
          <Text style={styles.a}>2.0 B</Text>
        </Text>
      </Text>
      <View style={[styles.rectangleView, styles.etlPosition]} />
      <Text
        style={[
          styles.bcse103eComputerProgrammingContainer,
          styles.containerPosition6,
        ]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`BCSE103E
`}</Text>
          <Text style={styles.engineeringChemistry}>
            Computer Programming: Java
          </Text>
        </Text>
      </Text>
      <Text
        style={[styles.creditsGrade30Container2, styles.containerPosition6]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`Credits         Grade
`}</Text>
          <Text style={styles.a}>3.0 A</Text>
        </Text>
      </Text>
      <Text style={[styles.th, styles.thTypo]}>TH</Text>
      <Text style={[styles.lo, styles.thTypo]}>LO</Text>
      <Text style={[styles.etl, styles.thTypo]}>ETL</Text>
      <View style={[styles.effectiveGradeHistoryChild1, styles.ssPosition]} />
      <Text
        style={[
          styles.bsts202pQuantitativeSkillsContainer,
          styles.containerPosition5,
        ]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`BSTS202P
`}</Text>
          <Text style={styles.engineeringChemistry}>
            Quantitative Skills Practice II
          </Text>
        </Text>
      </Text>
      <Text style={[styles.creditsGrade15Container, styles.containerPosition5]}>
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`Credits         Grade
`}</Text>
          <Text style={styles.a}>1.5 S</Text>
        </Text>
      </Text>
      <Text style={[styles.ss, styles.ssPosition]}>SS</Text>
      <View style={[styles.effectiveGradeHistoryChild2, styles.ocPosition]} />
      <View style={[styles.effectiveGradeHistoryChild2, styles.ocPosition]} />
      <Text
        style={[
          styles.cfoc306mSocialNetworksContainer,
          styles.containerPosition4,
        ]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`CFOC306M
`}</Text>
          <Text style={styles.engineeringChemistry}>Social Networks</Text>
        </Text>
      </Text>
      <Text
        style={[styles.creditsGrade30Container4, styles.containerPosition4]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`Credits         Grade
`}</Text>
          <Text style={styles.a}>3.0 S</Text>
        </Text>
      </Text>
      <Text style={[styles.oc, styles.ocPosition]}>OC</Text>
      <View style={[styles.effectiveGradeHistoryChild4, styles.oc1Position]} />
      <View style={[styles.effectiveGradeHistoryChild4, styles.oc1Position]} />
      <Text
        style={[
          styles.cfoc306mSocialNetworksContainer2,
          styles.containerPosition3,
        ]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`CFOC306M
`}</Text>
          <Text style={styles.engineeringChemistry}>Social Networks</Text>
        </Text>
      </Text>
      <Text
        style={[styles.creditsGrade30Container6, styles.containerPosition3]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`Credits         Grade
`}</Text>
          <Text style={styles.a}>3.0 S</Text>
        </Text>
      </Text>
      <Text style={[styles.oc1, styles.oc1Position]}>OC</Text>
      <View style={[styles.effectiveGradeHistoryChild6, styles.oc2Position]} />
      <View style={[styles.effectiveGradeHistoryChild6, styles.oc2Position]} />
      <Text
        style={[
          styles.cfoc306mSocialNetworksContainer4,
          styles.containerPosition2,
        ]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`CFOC306M
`}</Text>
          <Text style={styles.engineeringChemistry}>Social Networks</Text>
        </Text>
      </Text>
      <Text
        style={[styles.creditsGrade30Container8, styles.containerPosition2]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`Credits         Grade
`}</Text>
          <Text style={styles.a}>3.0 S</Text>
        </Text>
      </Text>
      <Text style={[styles.oc2, styles.oc2Position]}>OC</Text>
      <View style={[styles.effectiveGradeHistoryChild8, styles.oc3Position]} />
      <View style={[styles.effectiveGradeHistoryChild8, styles.oc3Position]} />
      <View style={[styles.effectiveGradeHistoryChild8, styles.oc3Position]} />
      <Text
        style={[
          styles.cfoc306mSocialNetworksContainer6,
          styles.containerPosition1,
        ]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`CFOC306M
`}</Text>
          <Text style={styles.engineeringChemistry}>Social Networks</Text>
        </Text>
      </Text>
      <Text
        style={[styles.creditsGrade30Container10, styles.containerPosition1]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`Credits         Grade
`}</Text>
          <Text style={styles.a}>3.0 S</Text>
        </Text>
      </Text>
      <Text style={[styles.oc3, styles.oc3Position]}>OC</Text>
      <View style={[styles.effectiveGradeHistoryChild11, styles.oc4Position]} />
      <View style={[styles.effectiveGradeHistoryChild11, styles.oc4Position]} />
      <View style={[styles.effectiveGradeHistoryChild11, styles.oc4Position]} />
      <Text
        style={[
          styles.cfoc306mSocialNetworksContainer8,
          styles.containerPosition,
        ]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`CFOC306M
`}</Text>
          <Text style={styles.engineeringChemistry}>Social Networks</Text>
        </Text>
      </Text>
      <Text
        style={[styles.creditsGrade30Container12, styles.containerPosition]}
      >
        <Text style={styles.bchy101lEngineeringChemistryContainer1}>
          <Text style={styles.bchy101l}>{`Credits         Grade
`}</Text>
          <Text style={styles.a}>3.0 S</Text>
        </Text>
      </Text>
      <Text style={[styles.oc4, styles.oc4Position]}>OC</Text>
      <View style={styles.effectiveGradeHistoryChild14} />
      <View style={styles.effectiveGradeHistoryChild15} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={styles.effectiveGradeHistoryChild15} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        color="#c3cfb7"
        onPress={() =>
          navigation.navigate("BottomTabsRoot", { screen: "GradeHistoryMenu" })
        }
        containerStyle={styles.lineIconBtn}
        buttonStyle={styles.lineIconBtn1}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  lineIconBtn: {
    left: 23,
    top: 32,
    position: "absolute",
  },
  lineIconBtn1: {
    borderStyle: "solid",
    width: 11,
    height: 18,
  },
  effectiveChildLayout: {
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
    left: 23,
  },
  containerPosition8: {
    height: 62,
    alignItems: "flex-end",
    fontSize: FontSize.size_xs,
    top: 133,
    display: "flex",
    position: "absolute",
  },
  creditsContainerLayout: {
    width: 119,
    left: 215,
    textAlign: "center",
  },
  loPosition: {
    top: 207,
    position: "absolute",
  },
  containerPosition7: {
    top: 212,
    height: 62,
    alignItems: "flex-end",
    fontSize: FontSize.size_xs,
    display: "flex",
    position: "absolute",
  },
  etlPosition: {
    top: 286,
    position: "absolute",
  },
  containerPosition6: {
    top: 291,
    height: 62,
    alignItems: "flex-end",
    fontSize: FontSize.size_xs,
    display: "flex",
    position: "absolute",
  },
  thTypo: {
    height: 15,
    width: 27,
    fontSize: FontSize.size_3xs,
    color: Color.colorDarkseagreen,
    fontFamily: FontFamily.kumbhSansBold,
    fontWeight: "700",
    alignItems: "flex-end",
    left: 28,
    display: "flex",
    textAlign: "left",
  },
  ssPosition: {
    top: 365,
    position: "absolute",
  },
  containerPosition5: {
    top: 370,
    height: 62,
    alignItems: "flex-end",
    fontSize: FontSize.size_xs,
    display: "flex",
    position: "absolute",
  },
  ocPosition: {
    top: 444,
    position: "absolute",
  },
  containerPosition4: {
    top: 449,
    height: 62,
    alignItems: "flex-end",
    fontSize: FontSize.size_xs,
    display: "flex",
    position: "absolute",
  },
  oc1Position: {
    top: 523,
    position: "absolute",
  },
  containerPosition3: {
    top: 528,
    height: 62,
    alignItems: "flex-end",
    fontSize: FontSize.size_xs,
    display: "flex",
    position: "absolute",
  },
  oc2Position: {
    top: 602,
    position: "absolute",
  },
  containerPosition2: {
    top: 607,
    height: 62,
    alignItems: "flex-end",
    fontSize: FontSize.size_xs,
    display: "flex",
    position: "absolute",
  },
  oc3Position: {
    top: 681,
    position: "absolute",
  },
  containerPosition1: {
    top: 686,
    height: 62,
    alignItems: "flex-end",
    fontSize: FontSize.size_xs,
    display: "flex",
    position: "absolute",
  },
  oc4Position: {
    top: 760,
    position: "absolute",
  },
  containerPosition: {
    top: 765,
    height: 62,
    alignItems: "flex-end",
    fontSize: FontSize.size_xs,
    display: "flex",
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    justifyContent: "center",
    letterSpacing: 0.2,
    fontSize: FontSize.size_mini,
    top: 766,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
    textAlign: "center",
    alignItems: "center",
    display: "flex",
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorFlexBox: {
    flexDirection: "row",
    backgroundColor: Color.colorLightgray,
  },
  effectiveGrades: {
    top: 81,
    fontSize: FontSize.size_lgi,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
    width: 148,
    height: 47,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.colorWhite,
    left: 23,
    position: "absolute",
  },
  marksparkVit: {
    top: 29,
    left: 93,
    fontSize: FontSize.size_xl,
    letterSpacing: 1.8,
    lineHeight: 24,
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    fontWeight: "300",
    color: Color.colorWhite,
    position: "absolute",
  },
  effectiveGradeHistoryChild: {
    top: 33,
    left: 305,
    width: 29,
    height: 16,
    position: "absolute",
  },
  effectiveGradeHistoryItem: {
    top: 128,
    position: "absolute",
  },
  bchy101l: {
    color: Color.colorDarkseagreen,
    fontFamily: FontFamily.kumbhSansBold,
    fontWeight: "700",
  },
  engineeringChemistry: {
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
  },
  bchy101lEngineeringChemistryContainer1: {
    width: "100%",
  },
  bchy101lEngineeringChemistryContainer: {
    width: 184,
    left: 28,
    textAlign: "left",
  },
  a: {
    fontFamily: FontFamily.kumbhSansLight,
    color: Color.colorLightgray,
    fontWeight: "300",
  },
  creditsGrade30Container: {
    height: 62,
    alignItems: "flex-end",
    fontSize: FontSize.size_xs,
    top: 133,
    display: "flex",
    position: "absolute",
  },
  effectiveGradeHistoryInner: {
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
    left: 23,
  },
  bcse102pStructuredAndContainer: {
    width: 184,
    left: 28,
    textAlign: "left",
  },
  creditsGrade20Container: {
    width: 119,
    left: 215,
    textAlign: "center",
  },
  rectangleView: {
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
    left: 23,
  },
  bcse103eComputerProgrammingContainer: {
    width: 184,
    left: 28,
    textAlign: "left",
  },
  creditsGrade30Container2: {
    width: 119,
    left: 215,
    textAlign: "center",
  },
  th: {
    top: 128,
    position: "absolute",
  },
  lo: {
    top: 207,
    position: "absolute",
  },
  etl: {
    top: 286,
    position: "absolute",
  },
  effectiveGradeHistoryChild1: {
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
    left: 23,
  },
  bsts202pQuantitativeSkillsContainer: {
    width: 184,
    left: 28,
    textAlign: "left",
  },
  creditsGrade15Container: {
    width: 119,
    left: 215,
    textAlign: "center",
  },
  ss: {
    height: 15,
    width: 27,
    fontSize: FontSize.size_3xs,
    color: Color.colorDarkseagreen,
    fontFamily: FontFamily.kumbhSansBold,
    fontWeight: "700",
    alignItems: "flex-end",
    left: 28,
    display: "flex",
    textAlign: "left",
  },
  effectiveGradeHistoryChild2: {
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
    left: 23,
  },
  cfoc306mSocialNetworksContainer: {
    width: 184,
    left: 28,
    textAlign: "left",
  },
  creditsGrade30Container4: {
    width: 119,
    left: 215,
    textAlign: "center",
  },
  oc: {
    height: 15,
    width: 27,
    fontSize: FontSize.size_3xs,
    color: Color.colorDarkseagreen,
    fontFamily: FontFamily.kumbhSansBold,
    fontWeight: "700",
    alignItems: "flex-end",
    left: 28,
    display: "flex",
    textAlign: "left",
  },
  effectiveGradeHistoryChild4: {
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
    left: 23,
  },
  cfoc306mSocialNetworksContainer2: {
    width: 184,
    left: 28,
    textAlign: "left",
  },
  creditsGrade30Container6: {
    width: 119,
    left: 215,
    textAlign: "center",
  },
  oc1: {
    height: 15,
    width: 27,
    fontSize: FontSize.size_3xs,
    color: Color.colorDarkseagreen,
    fontFamily: FontFamily.kumbhSansBold,
    fontWeight: "700",
    alignItems: "flex-end",
    left: 28,
    display: "flex",
    textAlign: "left",
  },
  effectiveGradeHistoryChild6: {
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
    left: 23,
  },
  cfoc306mSocialNetworksContainer4: {
    width: 184,
    left: 28,
    textAlign: "left",
  },
  creditsGrade30Container8: {
    width: 119,
    left: 215,
    textAlign: "center",
  },
  oc2: {
    height: 15,
    width: 27,
    fontSize: FontSize.size_3xs,
    color: Color.colorDarkseagreen,
    fontFamily: FontFamily.kumbhSansBold,
    fontWeight: "700",
    alignItems: "flex-end",
    left: 28,
    display: "flex",
    textAlign: "left",
  },
  effectiveGradeHistoryChild8: {
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
    left: 23,
  },
  cfoc306mSocialNetworksContainer6: {
    width: 184,
    left: 28,
    textAlign: "left",
  },
  creditsGrade30Container10: {
    width: 119,
    left: 215,
    textAlign: "center",
  },
  oc3: {
    height: 15,
    width: 27,
    fontSize: FontSize.size_3xs,
    color: Color.colorDarkseagreen,
    fontFamily: FontFamily.kumbhSansBold,
    fontWeight: "700",
    alignItems: "flex-end",
    left: 28,
    display: "flex",
    textAlign: "left",
  },
  effectiveGradeHistoryChild11: {
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
    left: 23,
  },
  cfoc306mSocialNetworksContainer8: {
    width: 184,
    left: 28,
    textAlign: "left",
  },
  creditsGrade30Container12: {
    width: 119,
    left: 215,
    textAlign: "center",
  },
  oc4: {
    height: 15,
    width: 27,
    fontSize: FontSize.size_3xs,
    color: Color.colorDarkseagreen,
    fontFamily: FontFamily.kumbhSansBold,
    fontWeight: "700",
    alignItems: "flex-end",
    left: 28,
    display: "flex",
    textAlign: "left",
  },
  effectiveGradeHistoryChild14: {
    top: 214,
    left: 347,
    borderRadius: Border.br_9xs_5,
    width: 7,
    height: 242,
    backgroundColor: Color.colorLightgray,
    position: "absolute",
  },
  effectiveGradeHistoryChild15: {
    top: 710,
    left: 0,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    position: "absolute",
  },
  home: {
    left: 6,
  },
  grades: {
    left: 96,
  },
  gpa: {
    left: 186,
  },
  cgpa: {
    left: 276,
  },
  vectorIcon: {
    right: "81.11%",
    left: "6.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.94%",
    left: "57.22%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.94%",
    left: "81.94%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.56%",
    left: "30.83%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  effectiveGradeHistory: {
    backgroundColor: Color.colorGray,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default EffectiveGradeHistory;
