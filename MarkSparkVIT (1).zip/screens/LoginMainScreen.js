import * as React from "react";
import { Text, StyleSheet, View, TextInput } from "react-native";
import { Button } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border, Padding } from "../GlobalStyles";

const LoginMainScreen = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.loginMainScreen, styles.passwordFlexBox]}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <View style={styles.loginBox}>
        <View style={styles.loginText}>
          <Text style={styles.loginMessage} numberOfLines={2}>
            <Text style={styles.login}>{`Login
`}</Text>
            <Text style={styles.usingYourVtop}>
              Using your VTOP credentials
            </Text>
          </Text>
        </View>
        <TextInput
          style={[styles.username, styles.usernameTypo]}
          placeholder="Username"
          placeholderTextColor="#c3cfb7"
        />
        <Button
          title="Sign in"
          radius={5}
          iconPosition="left"
          type="solid"
          titleStyle={styles.buttonBtn}
          onPress={() => navigation.navigate("LoginCaptcha")}
          containerStyle={styles.buttonBtn1}
          buttonStyle={styles.buttonBtn2}
        />
        <TextInput
          style={[styles.password, styles.usernameTypo]}
          placeholder=" Password"
          placeholderTextColor="#c3cfb7"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  buttonBtn: {
    color: "#b4d99a",
    fontSize: 24,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  buttonBtn1: {
    left: 75,
    top: 410,
    position: "absolute",
  },
  buttonBtn2: {
    width: 182,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#395922",
    borderRadius: 100,
  },
  passwordFlexBox: {
    justifyContent: "center",
    overflow: "hidden",
  },
  usernameTypo: {
    borderRadius: 100,
    backgroundColor: "#35402F",
    height: 62,
    fontFamily: FontFamily.kumbhSansLight,
    position: "absolute",
    fontWeight: "300",
    fontSize: FontSize.size_xl,
  },
  marksparkVit: {
    letterSpacing: 1.8,
    lineHeight: 24,
    fontFamily: FontFamily.comfortaaLight,
    color: Color.colorWhite,
    textAlign: "center",
    fontWeight: "300",
    fontSize: FontSize.size_xl,
  },
  login: {
    fontSize: FontSize.size_21xl,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
  },
  usingYourVtop: {
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.kumbhSansLight,
    fontWeight: "300",
  },
  loginMessage: {
    color: Color.colorGainsboro_100,
    textAlign: "left",
    width: 249,
    height: 78,
  },
  loginText: {
    top: 0,
    left: 12,
    width: 308,
    position: "absolute",
    justifyContent: "center",
    overflow: "hidden",
  },
  username: {
    top: 157,
    left: 1,
    borderRadius: Border.br_12xl,
    backgroundColor: Color.colorDarkslategray_100,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 330,
    flexDirection: "row",
    paddingLeft: Padding.p_2xs,
    paddingTop: Padding.p_6xs,
    paddingBottom: Padding.p_6xs,
    alignItems: "center",
  },
  password: {
    top: 238,
    left: 0,
    width: 332,
    alignItems: "flex-end",
    justifyContent: "center",
    overflow: "hidden",
  },
  loginBox: {
    alignSelf: "stretch",
    height: 472,
    marginTop: 79,
    overflow: "hidden",
  },
  loginMainScreen: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    paddingHorizontal: Padding.p_sm,
    paddingVertical: Padding.p_21xl,
    alignItems: "center",
  },
});

export default LoginMainScreen;
