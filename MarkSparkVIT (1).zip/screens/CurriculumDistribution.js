import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const CurriculumDistribution = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.curriculumDistribution}>
      <Text style={styles.curriculumDistribution1}>
        Curriculum Distribution
      </Text>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.curriculumDistributionChild}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <View
        style={[
          styles.curriculumDistributionItem,
          styles.curriculumChildLayout4,
        ]}
      />
      <Text style={[styles.foundationCoreBasicSciences, styles.foundationTypo]}>
        Foundation Core-Basic Sciences and Mathematics
      </Text>
      <View
        style={[
          styles.curriculumDistributionInner,
          styles.curriculumChildLayout3,
        ]}
      />
      <View style={[styles.rectangleView, styles.curriculumChildLayout2]} />
      <Text style={[styles.text, styles.textTypo1]}>24.0/ 24.0</Text>
      <View
        style={[
          styles.curriculumDistributionChild1,
          styles.curriculumChildLayout4,
        ]}
      />
      <Text style={[styles.foundationCoreHumanitiesSo, styles.foundationTypo]}>
        Foundation Core-Humanities, Social Sciences and Management
      </Text>
      <View
        style={[
          styles.curriculumDistributionChild2,
          styles.curriculumChildLayout3,
        ]}
      />
      <View
        style={[
          styles.curriculumDistributionChild3,
          styles.curriculumChildLayout2,
        ]}
      />
      <Text style={[styles.text1, styles.textTypo1]}>12.0/ 15.0</Text>
      <View
        style={[
          styles.curriculumDistributionChild4,
          styles.curriculumChildLayout4,
        ]}
      />
      <Text style={[styles.foundationCoreBasicEngineer, styles.foundationTypo]}>
        Foundation Core-Basic Engineering Sciences
      </Text>
      <View
        style={[
          styles.curriculumDistributionChild5,
          styles.curriculumChildLayout3,
        ]}
      />
      <View
        style={[
          styles.curriculumDistributionChild6,
          styles.curriculumChildLayout2,
        ]}
      />
      <Text style={[styles.text2, styles.textTypo1]}>16.0/ 16.0</Text>
      <View
        style={[
          styles.curriculumDistributionChild7,
          styles.curriculumChildLayout4,
        ]}
      />
      <Text style={[styles.disciplineLinkedEngineering, styles.foundationTypo]}>
        Discipline-Linked Engineering Sciences
      </Text>
      <View
        style={[
          styles.curriculumDistributionChild8,
          styles.curriculumChildLayout3,
        ]}
      />
      <View
        style={[
          styles.curriculumDistributionChild9,
          styles.curriculumChildLayout2,
        ]}
      />
      <Text style={[styles.text3, styles.textTypo1]}>12.0/ 12.0</Text>
      <View
        style={[
          styles.curriculumDistributionChild10,
          styles.curriculumChildLayout4,
        ]}
      />
      <Text
        style={[styles.disciplineLinkedEngineering1, styles.disciplineTypo]}
      >
        Discipline-Linked Engineering Sciences
      </Text>
      <View
        style={[
          styles.curriculumDistributionChild11,
          styles.curriculumChildLayout1,
        ]}
      />
      <View
        style={[
          styles.curriculumDistributionChild12,
          styles.curriculumChildLayout,
        ]}
      />
      <Text style={[styles.text4, styles.textTypo]}>12.0/ 12.0</Text>
      <View
        style={[
          styles.curriculumDistributionChild13,
          styles.curriculumChildLayout4,
        ]}
      />
      <Text
        style={[styles.disciplineLinkedEngineering2, styles.disciplineTypo]}
      >
        Discipline-Linked Engineering Sciences
      </Text>
      <View
        style={[
          styles.curriculumDistributionChild14,
          styles.curriculumChildLayout1,
        ]}
      />
      <View
        style={[
          styles.curriculumDistributionChild15,
          styles.curriculumChildLayout,
        ]}
      />
      <Text style={[styles.text5, styles.textTypo]}>12.0/ 12.0</Text>
      <View
        style={[
          styles.curriculumDistributionChild16,
          styles.curriculumChildLayout4,
        ]}
      />
      <Text
        style={[styles.disciplineLinkedEngineering3, styles.foundationTypo]}
      >
        Discipline-Linked Engineering Sciences
      </Text>
      <View
        style={[
          styles.curriculumDistributionChild17,
          styles.curriculumChildLayout3,
        ]}
      />
      <View
        style={[
          styles.curriculumDistributionChild18,
          styles.curriculumChildLayout2,
        ]}
      />
      <Text style={[styles.text6, styles.textTypo1]}>12.0/ 12.0</Text>
      <View
        style={[
          styles.curriculumDistributionChild19,
          styles.curriculumChildLayout4,
        ]}
      />
      <Text style={[styles.totalCredits, styles.disciplineTypo]}>
        Total Credits
      </Text>
      <View
        style={[
          styles.curriculumDistributionChild20,
          styles.curriculumChildLayout1,
        ]}
      />
      <View
        style={[
          styles.curriculumDistributionChild21,
          styles.curriculumChildLayout,
        ]}
      />
      <Text style={[styles.text7, styles.text7Position]}>108.5/ 150.0</Text>
      <View style={styles.curriculumDistributionChild22} />
      <View
        style={[styles.curriculumDistributionChild23, styles.text7Position]}
      />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View
        style={[styles.curriculumDistributionChild23, styles.text7Position]}
      />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        color="#c3cfb7"
        onPress={() =>
          navigation.navigate("BottomTabsRoot", { screen: "GradeHistoryMenu" })
        }
        containerStyle={styles.lineIconBtn}
        buttonStyle={styles.lineIconBtn1}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  lineIconBtn: {
    left: 23,
    top: 32,
    position: "absolute",
  },
  lineIconBtn1: {
    borderStyle: "solid",
    width: 11,
    height: 18,
  },
  curriculumChildLayout4: {
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
    position: "absolute",
  },
  foundationTypo: {
    height: 61,
    width: 180,
    color: Color.colorDarkseagreen,
    fontSize: FontSize.size_xs,
    left: 29,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    position: "absolute",
  },
  curriculumChildLayout3: {
    height: 66,
    width: 68,
    backgroundColor: Color.colorDarkseagreen,
    borderRadius: Border.br_27xl_5,
    left: 266,
    position: "absolute",
  },
  curriculumChildLayout2: {
    height: 44,
    width: 44,
    borderRadius: Border.br_10xl_5,
    left: 278,
    backgroundColor: Color.colorDarkolivegreen_200,
    position: "absolute",
  },
  textTypo1: {
    height: 28,
    width: 35,
    justifyContent: "center",
    fontSize: FontSize.size_2xs,
    left: 283,
    color: Color.colorDarkseagreen,
    textAlign: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    position: "absolute",
  },
  disciplineTypo: {
    left: 28,
    height: 61,
    width: 180,
    color: Color.colorDarkseagreen,
    fontSize: FontSize.size_xs,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    position: "absolute",
  },
  curriculumChildLayout1: {
    left: 265,
    height: 66,
    width: 68,
    backgroundColor: Color.colorDarkseagreen,
    borderRadius: Border.br_27xl_5,
    position: "absolute",
  },
  curriculumChildLayout: {
    left: 277,
    height: 44,
    width: 44,
    borderRadius: Border.br_10xl_5,
    backgroundColor: Color.colorDarkolivegreen_200,
    position: "absolute",
  },
  textTypo: {
    left: 282,
    height: 28,
    width: 35,
    justifyContent: "center",
    fontSize: FontSize.size_2xs,
    color: Color.colorDarkseagreen,
    textAlign: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
  },
  text7Position: {
    top: 710,
    position: "absolute",
  },
  gpaTypo: {
    height: 34,
    width: 78,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
    letterSpacing: 0.2,
    fontSize: FontSize.size_mini,
    top: 766,
    justifyContent: "center",
    textAlign: "center",
    alignItems: "center",
    display: "flex",
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorFlexBox: {
    flexDirection: "row",
    backgroundColor: Color.colorLightgray,
  },
  curriculumDistribution1: {
    top: 81,
    fontSize: FontSize.size_lgi,
    width: 217,
    height: 47,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    left: 23,
    position: "absolute",
  },
  marksparkVit: {
    top: 29,
    left: 93,
    fontSize: FontSize.size_xl,
    letterSpacing: 1.8,
    lineHeight: 24,
    fontWeight: "300",
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  curriculumDistributionChild: {
    top: 33,
    left: 305,
    width: 29,
    height: 16,
    position: "absolute",
  },
  curriculumDistributionItem: {
    top: 128,
    left: 23,
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
  },
  foundationCoreBasicSciences: {
    top: 133,
  },
  curriculumDistributionInner: {
    top: 131,
  },
  rectangleView: {
    top: 142,
  },
  text: {
    top: 150,
  },
  curriculumDistributionChild1: {
    top: 288,
    left: 23,
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
  },
  foundationCoreHumanitiesSo: {
    top: 293,
  },
  curriculumDistributionChild2: {
    top: 291,
  },
  curriculumDistributionChild3: {
    top: 302,
  },
  text1: {
    top: 310,
  },
  curriculumDistributionChild4: {
    top: 208,
    left: 23,
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
  },
  foundationCoreBasicEngineer: {
    top: 213,
  },
  curriculumDistributionChild5: {
    top: 211,
  },
  curriculumDistributionChild6: {
    top: 222,
  },
  text2: {
    top: 230,
  },
  curriculumDistributionChild7: {
    top: 368,
    left: 23,
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
  },
  disciplineLinkedEngineering: {
    top: 373,
  },
  curriculumDistributionChild8: {
    top: 371,
  },
  curriculumDistributionChild9: {
    top: 382,
  },
  text3: {
    top: 390,
  },
  curriculumDistributionChild10: {
    top: 448,
    left: 23,
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
  },
  disciplineLinkedEngineering1: {
    top: 453,
  },
  curriculumDistributionChild11: {
    top: 451,
  },
  curriculumDistributionChild12: {
    top: 462,
  },
  text4: {
    top: 470,
    position: "absolute",
  },
  curriculumDistributionChild13: {
    top: 528,
    left: 22,
  },
  disciplineLinkedEngineering2: {
    top: 533,
  },
  curriculumDistributionChild14: {
    top: 531,
  },
  curriculumDistributionChild15: {
    top: 542,
  },
  text5: {
    top: 550,
    position: "absolute",
  },
  curriculumDistributionChild16: {
    top: 608,
    left: 23,
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
  },
  disciplineLinkedEngineering3: {
    top: 613,
  },
  curriculumDistributionChild17: {
    top: 611,
  },
  curriculumDistributionChild18: {
    top: 622,
  },
  text6: {
    top: 630,
  },
  curriculumDistributionChild19: {
    top: 688,
    left: 23,
    height: 72,
    width: 315,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_mini,
  },
  totalCredits: {
    top: 693,
  },
  curriculumDistributionChild20: {
    top: 691,
  },
  curriculumDistributionChild21: {
    top: 702,
  },
  text7: {
    left: 282,
    height: 28,
    width: 35,
    justifyContent: "center",
    fontSize: FontSize.size_2xs,
    color: Color.colorDarkseagreen,
    textAlign: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
  },
  curriculumDistributionChild22: {
    top: 283,
    left: 347,
    borderRadius: Border.br_9xs_5,
    width: 7,
    height: 242,
    backgroundColor: Color.colorLightgray,
    position: "absolute",
  },
  curriculumDistributionChild23: {
    left: 0,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
  },
  home: {
    left: 6,
  },
  grades: {
    left: 96,
  },
  gpa: {
    left: 186,
  },
  cgpa: {
    left: 276,
  },
  vectorIcon: {
    right: "81.11%",
    left: "6.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.94%",
    left: "57.22%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.94%",
    left: "81.94%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.56%",
    left: "30.83%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  curriculumDistribution: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default CurriculumDistribution;
