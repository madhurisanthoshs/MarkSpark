import * as React from "react";
import { Text, StyleSheet, TextInput, View } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const CGPAMainScreen = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.cgpaMainScreen}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.cgpaMainScreenChild}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <Text style={styles.cgpaPredictor}>CGPA Predictor</Text>
      <TextInput
        style={[styles.cgpaMainScreenItem, styles.cgpaTypo]}
        placeholder="Enter credits till last semester"
        placeholderTextColor="#c3cfb7"
      />
      <TextInput
        style={[styles.cgpaMainScreenInner, styles.cgpaTypo]}
        placeholder="Enter credits for this semester"
        placeholderTextColor="#c3cfb7"
      />
      <TextInput
        style={[styles.frameTextinput, styles.cgpaTypo]}
        placeholder="Enter CGPA for this semester"
        placeholderTextColor="#c3cfb7"
      />
      <TextInput
        style={[styles.cgpaMainScreenChild1, styles.cgpaTypo]}
        placeholder="Enter CGPA till last semester"
        placeholderTextColor="#c3cfb7"
      />
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.cgpaMainScreenChild5} />
      <Button
        title="Submit"
        radius={5}
        iconPosition="left"
        type="solid"
        titleStyle={styles.submitButtonBtn}
        onPress={() => navigation.navigate("CGPACalculatedCGPA")}
        containerStyle={styles.submitButtonBtn1}
        buttonStyle={styles.submitButtonBtn2}
      />
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        onPress={() =>
          navigation.navigate("BottomTabsRoot", { screen: "CGPAMenu" })
        }
        containerStyle={styles.lineIconBtn}
        buttonStyle={styles.lineIconBtn1}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  submitButtonBtn: {
    color: "#b4d99a",
    fontSize: 24,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  submitButtonBtn1: {
    left: 124,
    top: 612,
    position: "absolute",
  },
  submitButtonBtn2: {
    width: 113,
    height: 48,
    backgroundColor: "#395922",
    borderRadius: 100,
  },
  lineIconBtn: {
    left: 18,
    top: 24,
    position: "absolute",
  },
  lineIconBtn1: {
    borderStyle: "solid",
    width: 11,
    height: 18,
    backgroundColor: "#C3CFB7",
  },
  cgpaTypo: {
    backgroundColor: "#35402F",
    borderRadius: 100,
    fontFamily: FontFamily.kumbhSansLight,
    height: 62,
    width: 330,
    left: 15,
    fontWeight: "300",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    justifyContent: "center",
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
    letterSpacing: 0.2,
    fontSize: FontSize.size_mini,
    top: 766,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout2: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconLayout: {
    flexDirection: "row",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  marksparkVit: {
    top: 23,
    left: 80,
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    color: Color.colorWhite,
    fontWeight: "300",
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  cgpaMainScreenChild: {
    top: 25,
    left: 310,
    width: 29,
    height: 16,
    position: "absolute",
  },
  cgpaPredictor: {
    top: 88,
    left: 18,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
    textAlign: "left",
    width: 204,
    height: 39,
    alignItems: "center",
    display: "flex",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  cgpaMainScreenItem: {
    top: 155,
  },
  cgpaMainScreenInner: {
    top: 313,
  },
  frameTextinput: {
    top: 390,
  },
  cgpaMainScreenChild1: {
    top: 234,
  },
  rectangleView: {
    top: 710,
    left: 0,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    position: "absolute",
  },
  home: {
    left: 6,
  },
  grades: {
    left: 96,
  },
  gpa: {
    left: 186,
  },
  cgpa: {
    left: 276,
  },
  vectorIcon: {
    right: "81.11%",
    left: "6.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.94%",
    left: "57.22%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.94%",
    left: "81.94%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.56%",
    left: "30.83%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  cgpaMainScreenChild5: {
    top: 502,
    left: 37,
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorDarkolivegreen_200,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 1,
    width: 286,
    height: 60,
    position: "absolute",
  },
  cgpaMainScreen: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default CGPAMainScreen;
