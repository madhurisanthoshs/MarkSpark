import React, { useState } from "react";
import { StyleSheet, View, Text } from "react-native";
import { ActivityIndicator } from "react-native-paper";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const GPALoadingScreen = () => {
  const [frameActivityIndicatorAnimating, setFrameActivityIndicatorAnimating] =
    useState(true);

  return (
    <View style={styles.gpaLoadingScreen}>
      <View style={[styles.gpaLoadingScreenChild, styles.childPosition]} />
      <View style={[styles.frameParent, styles.frameParentLayout]}>
        <ActivityIndicator
          style={[styles.frameChild, styles.childPosition]}
          animating={frameActivityIndicatorAnimating}
          size="[object Object]"
          color="#939393"
        />
        <Text style={[styles.calculating, styles.frameParentLayout]}>
          Calculating...
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  childPosition: {
    top: 0,
    position: "absolute",
  },
  frameParentLayout: {
    width: 195,
    position: "absolute",
  },
  gpaLoadingScreenChild: {
    backgroundColor: Color.colorDarkslategray_100,
    width: 360,
    left: 0,
    height: 800,
  },
  frameChild: {
    left: 63,
    width: 69,
    height: 65,
  },
  calculating: {
    top: 98,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.kumbhSansRegular,
    color: Color.colorLightgray,
    textAlign: "center",
    height: 61,
    left: 0,
  },
  frameParent: {
    top: 320,
    left: 82,
    height: 159,
  },
  gpaLoadingScreen: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default GPALoadingScreen;
