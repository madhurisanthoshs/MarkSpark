import React, { useState } from "react";
import { View, StyleSheet, Text } from "react-native";
import { ActivityIndicator } from "react-native-paper";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const CGPALoadingScreen = () => {
  const [
    loadingScreenActivityIndicatorAnimating,
    setLoadingScreenActivityIndicatorAnimating,
  ] = useState(true);

  return (
    <View style={styles.cgpaLoadingScreen}>
      <View style={[styles.cgpaLoadingScreenChild, styles.loadingPosition]} />
      <View style={[styles.cgpaLoadingScreenInner, styles.loadingLayout]}>
        <View style={[styles.loadingScreenParent, styles.loadingLayout]}>
          <ActivityIndicator
            style={styles.loadingScreen}
            animating={loadingScreenActivityIndicatorAnimating}
            size="[object Object]"
            color="#939393"
          />
          <Text style={styles.calculating}>Calculating...</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  loadingPosition: {
    left: 0,
    top: 0,
  },
  loadingLayout: {
    height: 159,
    width: 195,
    position: "absolute",
  },
  cgpaLoadingScreenChild: {
    backgroundColor: Color.colorDarkslategray_100,
    width: 360,
    position: "absolute",
    left: 0,
    height: 800,
  },
  loadingScreen: {
    left: 63,
    width: 69,
    height: 65,
    top: 0,
    position: "absolute",
  },
  calculating: {
    top: 98,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.kumbhSansRegular,
    color: Color.colorLightgray,
    textAlign: "center",
    height: 61,
    width: 195,
    left: 0,
    position: "absolute",
  },
  loadingScreenParent: {
    left: 0,
    top: 0,
  },
  cgpaLoadingScreenInner: {
    top: 320,
    left: 82,
  },
  cgpaLoadingScreen: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default CGPALoadingScreen;
