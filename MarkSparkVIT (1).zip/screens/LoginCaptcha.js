import * as React from "react";
import { StyleSheet, View, Text, TextInput } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const LoginCaptcha = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.loginCaptcha}>
      <View style={[styles.overlay, styles.overlayPosition]} />
      <View style={[styles.captchaBox, styles.captchaLayout]}>
        <View style={[styles.captchaBoxChild, styles.captchaLayout]} />
        <Text style={[styles.captcha, styles.captchaFlexBox]} numberOfLines={1}>
          Captcha
        </Text>
        <Image
          style={[styles.captchaImageIcon, styles.placeholderPosition]}
          contentFit="contain"
          source={require("../assets/captcha-image.png")}
        />
        <Text
          style={[styles.solveTheCaptcha, styles.captchaFlexBox]}
          numberOfLines={1}
        >
          Solve the captcha:
        </Text>
        <Button
          title="Submit"
          radius={5}
          iconPosition="left"
          type="solid"
          titleStyle={styles.submitButtonBtn}
          onPress={() =>
            navigation.navigate("BottomTabsRoot", { screen: "Dashboard" })
          }
          containerStyle={styles.submitButtonBtn1}
          buttonStyle={styles.submitButtonBtn2}
        />
        <Button
          title="Cancel"
          radius={10}
          iconPosition="left"
          type="solid"
          color="#395922"
          titleStyle={styles.cancelButtonBtn}
          onPress={() => navigation.navigate("LoginMainScreen")}
          containerStyle={styles.cancelButtonBtn1}
          buttonStyle={styles.cancelButtonBtn2}
        />
        <TextInput
          style={[styles.placeholder, styles.placeholderPosition]}
          placeholder="Captcha"
          placeholderTextColor="#c3cfb7"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  submitButtonBtn: {
    color: "#b4d99a",
    fontSize: 24,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  submitButtonBtn1: {
    left: 166,
    top: 257,
    position: "absolute",
  },
  submitButtonBtn2: {
    borderRadius: 100,
    width: 113,
    height: 48,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
    backgroundColor: "#395922",
  },
  cancelButtonBtn: {
    color: "#b4d99a",
    fontSize: 24,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  cancelButtonBtn1: {
    left: 12,
    top: 257,
    position: "absolute",
  },
  cancelButtonBtn2: {
    borderRadius: 100,
    width: 113,
    height: 48,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
    backgroundColor: "#395922",
  },
  overlayPosition: {
    left: 0,
    top: 0,
  },
  captchaLayout: {
    height: 315,
    width: 294,
    borderRadius: Border.br_20xl,
    position: "absolute",
  },
  captchaFlexBox: {
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.colorGainsboro_200,
    position: "absolute",
  },
  placeholderPosition: {
    width: 267,
    left: 12,
    position: "absolute",
  },
  overlay: {
    width: 360,
    backgroundColor: Color.colorDarkslategray_100,
    position: "absolute",
    left: 0,
    top: 0,
    height: 800,
  },
  captchaBoxChild: {
    backgroundColor: Color.colorGray,
    left: 0,
    top: 0,
  },
  captcha: {
    top: 16,
    fontSize: FontSize.size_13xl,
    letterSpacing: 0.3,
    fontFamily: FontFamily.kumbhSansRegular,
    width: 171,
    left: 12,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.colorGainsboro_200,
  },
  captchaImageIcon: {
    top: 75,
    height: 57,
  },
  solveTheCaptcha: {
    top: 144,
    left: 14,
    fontSize: FontSize.size_xl,
    letterSpacing: 0.2,
    fontWeight: "300",
    fontFamily: FontFamily.kumbhSansLight,
    width: 265,
    height: 32,
  },
  placeholder: {
    top: 182,
    borderRadius: 100,
    height: 56,
    backgroundColor: Color.colorDarkslategray_100,
    fontFamily: "Kumbh Sans ",
  },
  captchaBox: {
    top: 205,
    left: 33,
  },
  loginCaptcha: {
    backgroundColor: Color.colorBlack,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default LoginCaptcha;
