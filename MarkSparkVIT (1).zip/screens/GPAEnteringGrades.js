import React, { useState } from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import DropDownPicker from "react-native-dropdown-picker";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const GPAEnteringGrades = () => {
  const [frameDropdownOpen, setFrameDropdownOpen] = useState(false);
  const [frameDropdownValue, setFrameDropdownValue] = useState();
  const [frameDropdownItems, setFrameDropdownItems] = useState([
    { value: "S", label: "S" },
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
  ]);

  return (
    <View style={styles.gpaEnteringGrades}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <View style={[styles.gpaEnteringGradesChild, styles.gpaLayout]} />
      <View style={[styles.gpaEnteringGradesItem, styles.gpaLayout]} />
      <View style={[styles.gpaEnteringGradesInner, styles.gpaLayout]} />
      <Text style={styles.gpaPredictor}>GPA predictor</Text>
      <View style={[styles.rectangleView, styles.frameViewLayout]} />
      <Text style={[styles.submit, styles.submitTypo]}>Submit</Text>
      <View style={styles.gpaEnteringGradesChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <View style={styles.gpaEnteringGradesChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={[styles.gpaEnteringGradesChild3, styles.gpaChildLayout8]} />
      <View style={[styles.gpaEnteringGradesChild4, styles.gpaChildLayout7]} />
      <View style={[styles.gpaEnteringGradesChild5, styles.gpaChildLayout6]} />
      <View style={[styles.gpaEnteringGradesChild6, styles.gpaChildLayout5]} />
      <View style={[styles.gpaEnteringGradesChild7, styles.gpaChildLayout4]} />
      <View style={[styles.gpaEnteringGradesChild8, styles.gpaChildLayout3]} />
      <View style={[styles.gpaEnteringGradesChild9, styles.gpaChildLayout2]} />
      <View style={[styles.gpaEnteringGradesChild10, styles.gpaChildLayout8]} />
      <View style={[styles.gpaEnteringGradesChild11, styles.gpaChildLayout7]} />
      <View style={[styles.gpaEnteringGradesChild12, styles.gpaChildLayout6]} />
      <View style={[styles.gpaEnteringGradesChild13, styles.gpaChildLayout5]} />
      <View style={[styles.gpaEnteringGradesChild14, styles.gpaChildLayout4]} />
      <View style={[styles.gpaEnteringGradesChild15, styles.gpaChildLayout3]} />
      <View style={[styles.gpaEnteringGradesChild16, styles.gpaChildLayout2]} />
      <Text style={[styles.grade, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.lineIcon, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild17, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade1, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit1, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild18, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild19, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade2, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit2, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild20, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild21, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade3, styles.grade3Typo]}>Grade</Text>
      <Text style={[styles.credit3, styles.grade3Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild22, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild23, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade4, styles.grade4Typo]}>Grade</Text>
      <Text style={[styles.credit4, styles.grade4Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild24, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild25, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade5, styles.grade5Typo]}>Grade</Text>
      <Text style={[styles.credit5, styles.grade5Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild26, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild27, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade6, styles.grade6Typo]}>Grade</Text>
      <Text style={[styles.credit6, styles.grade6Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild28, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild29, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.frameIcon}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <Text style={styles.gpaPredictor}>GPA predictor</Text>
      <View style={[styles.gpaEnteringGradesChild30, styles.childShadowBox]} />
      <View style={[styles.frameView, styles.frameViewLayout]}>
        <View style={[styles.rectangleParent, styles.framePosition]}>
          <View style={[styles.frameChild, styles.framePosition]} />
          <Text style={[styles.submit1, styles.submitTypo]}>Submit</Text>
        </View>
      </View>
      <View style={styles.gpaEnteringGradesChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <View style={styles.gpaEnteringGradesChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <View style={[styles.gpaEnteringGradesChild3, styles.gpaChildLayout8]} />
      <View style={[styles.gpaEnteringGradesChild4, styles.gpaChildLayout7]} />
      <View style={[styles.gpaEnteringGradesChild5, styles.gpaChildLayout6]} />
      <View style={[styles.gpaEnteringGradesChild6, styles.gpaChildLayout5]} />
      <View style={[styles.gpaEnteringGradesChild7, styles.gpaChildLayout4]} />
      <View style={[styles.gpaEnteringGradesChild8, styles.gpaChildLayout3]} />
      <View style={[styles.gpaEnteringGradesChild9, styles.gpaChildLayout2]} />
      <View style={[styles.gpaEnteringGradesChild10, styles.gpaChildLayout8]} />
      <View style={[styles.gpaEnteringGradesChild11, styles.gpaChildLayout7]} />
      <View style={[styles.gpaEnteringGradesChild12, styles.gpaChildLayout6]} />
      <View style={[styles.gpaEnteringGradesChild13, styles.gpaChildLayout5]} />
      <View style={[styles.gpaEnteringGradesChild14, styles.gpaChildLayout4]} />
      <View style={[styles.gpaEnteringGradesChild15, styles.gpaChildLayout3]} />
      <View style={[styles.gpaEnteringGradesChild16, styles.gpaChildLayout2]} />
      <Text style={[styles.grade, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit, styles.gradeTypo]}>Credit</Text>
      <View style={[styles.lineIcon, styles.gpaChildLayout1]}>
        <DropDownPicker
          open={frameDropdownOpen}
          setOpen={setFrameDropdownOpen}
          value={frameDropdownValue}
          setValue={setFrameDropdownValue}
          items={frameDropdownItems}
        />
      </View>
      <Image
        style={[styles.gpaEnteringGradesChild17, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade1, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit1, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild18, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild19, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade2, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit2, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild20, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild21, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade3, styles.grade3Typo]}>Grade</Text>
      <Text style={[styles.credit3, styles.grade3Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild22, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild23, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade4, styles.grade4Typo]}>Grade</Text>
      <Text style={[styles.credit4, styles.grade4Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild24, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild25, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade5, styles.grade5Typo]}>Grade</Text>
      <Text style={[styles.credit5, styles.grade5Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild26, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild27, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade6, styles.grade6Typo]}>Grade</Text>
      <Text style={[styles.credit6, styles.grade6Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild28, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild29, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <View style={[styles.gpaEnteringGradesChild60, styles.gpaChildLayout]} />
      <View style={[styles.gpaEnteringGradesChild61, styles.gpaChildLayout]} />
      <Text style={[styles.grade14, styles.grade14Typo]}>Grade</Text>
      <Text style={[styles.credit14, styles.grade14Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild62, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild63, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <View style={[styles.gpaEnteringGradesChild60, styles.gpaChildLayout]} />
      <View style={[styles.gpaEnteringGradesChild61, styles.gpaChildLayout]} />
      <Text style={[styles.grade14, styles.grade14Typo]}>Grade</Text>
      <Text style={[styles.credit14, styles.grade14Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringGradesChild62, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringGradesChild63, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <View style={styles.gpaEnteringGradesChild68} />
      <View style={[styles.rectangleGroup, styles.frameItemLayout]}>
        <View style={[styles.frameItem, styles.frameItemLayout]} />
        <Image
          style={[styles.frameInner, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-51.png")}
        />
        <Image
          style={[styles.frameChild1, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-61.png")}
        />
        <Image
          style={[styles.frameChild2, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-7.png")}
        />
        <Image
          style={[styles.frameChild3, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-8.png")}
        />
        <Image
          style={[styles.frameChild4, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-91.png")}
        />
        <Image
          style={[styles.frameChild5, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-10.png")}
        />
        <Text style={[styles.s, styles.sTypo]}>S</Text>
        <Text style={[styles.a, styles.sTypo]}>A</Text>
        <Text style={[styles.b, styles.sTypo]}>B</Text>
        <Text style={[styles.c, styles.sTypo]}>C</Text>
        <Text style={[styles.d, styles.dTypo]}>D</Text>
        <Text style={[styles.e, styles.dTypo]}>E</Text>
        <Text style={[styles.f, styles.dTypo]}>F</Text>
      </View>
      <Image
        style={styles.gpaEnteringGradesChild69}
        contentFit="cover"
        source={require("../assets/line-181.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  gpaLayout: {
    height: 2,
    width: 31,
    borderTopWidth: 2,
    borderColor: Color.colorGainsboro_100,
    borderStyle: "solid",
    left: 309,
    position: "absolute",
  },
  frameViewLayout: {
    height: 48,
    width: 113,
    position: "absolute",
  },
  submitTypo: {
    height: 33,
    width: 84,
    justifyContent: "center",
    color: Color.colorDarkseagreen,
    letterSpacing: 0.2,
    fontSize: FontSize.size_5xl,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  gpaTypo: {
    height: 34,
    width: 78,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
    fontSize: FontSize.size_mini,
    top: 766,
    justifyContent: "center",
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout2: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  gpaChildLayout8: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    top: 126,
    borderRadius: Border.br_base,
    height: 39,
    position: "absolute",
  },
  gpaChildLayout7: {
    height: 38,
    top: 177,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    position: "absolute",
  },
  gpaChildLayout6: {
    top: 227,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    height: 39,
    position: "absolute",
  },
  gpaChildLayout5: {
    top: 278,
    height: 38,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    position: "absolute",
  },
  gpaChildLayout4: {
    top: 328,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    height: 39,
    position: "absolute",
  },
  gpaChildLayout3: {
    top: 379,
    height: 38,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    position: "absolute",
  },
  gpaChildLayout2: {
    top: 429,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    height: 39,
    position: "absolute",
  },
  gradeTypo: {
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  gpaChildLayout1: {
    height: 13,
    width: 19,
    left: 130,
    position: "absolute",
  },
  gpaChildPosition: {
    left: 284,
    height: 13,
    width: 19,
    position: "absolute",
  },
  grade3Typo: {
    top: 282,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  grade4Typo: {
    top: 333,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  grade5Typo: {
    top: 383,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  grade6Typo: {
    top: 433,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  childShadowBox: {
    borderWidth: 1,
    borderColor: Color.colorBlack,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkolivegreen_200,
    borderStyle: "solid",
  },
  framePosition: {
    left: 0,
    top: 0,
  },
  vectorIconLayout: {
    flexDirection: "row",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  gpaChildLayout: {
    top: 480,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    height: 39,
    position: "absolute",
  },
  grade14Typo: {
    top: 484,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  frameItemLayout: {
    height: 157,
    width: 94,
    position: "absolute",
  },
  frameChildLayout: {
    height: 1,
    width: 94,
    left: 0,
    position: "absolute",
  },
  sTypo: {
    height: 17,
    width: 32,
    fontSize: FontSize.size_base,
    left: 31,
    color: Color.colorLightgray,
    justifyContent: "center",
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  dTypo: {
    left: 32,
    height: 17,
    width: 32,
    fontSize: FontSize.size_base,
    color: Color.colorLightgray,
    justifyContent: "center",
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  marksparkVit: {
    top: 23,
    left: 80,
    fontWeight: "300",
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  gpaEnteringGradesChild: {
    top: 24,
  },
  gpaEnteringGradesItem: {
    top: 32,
  },
  gpaEnteringGradesInner: {
    top: 40,
  },
  gpaPredictor: {
    textAlign: "left",
    width: 204,
    height: 39,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    left: 15,
    top: 71,
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  rectangleView: {
    borderWidth: 1,
    borderColor: Color.colorBlack,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkolivegreen_200,
    borderStyle: "solid",
    borderRadius: Border.br_12xl,
    width: 113,
    left: 124,
    top: 640,
  },
  submit: {
    top: 648,
    left: 139,
  },
  gpaEnteringGradesChild1: {
    top: 710,
    left: 1,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    position: "absolute",
  },
  home: {
    left: 7,
  },
  grades: {
    left: 97,
  },
  gpa: {
    left: 187,
  },
  cgpa: {
    left: 277,
  },
  vectorIcon: {
    right: "80.83%",
    left: "6.39%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.67%",
    left: "57.5%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.67%",
    left: "82.22%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.28%",
    left: "31.11%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  gpaEnteringGradesChild3: {
    left: 38,
  },
  gpaEnteringGradesChild4: {
    left: 38,
  },
  gpaEnteringGradesChild5: {
    left: 38,
  },
  gpaEnteringGradesChild6: {
    left: 38,
  },
  gpaEnteringGradesChild7: {
    left: 38,
  },
  gpaEnteringGradesChild8: {
    left: 38,
  },
  gpaEnteringGradesChild9: {
    left: 38,
  },
  gpaEnteringGradesChild10: {
    left: 187,
  },
  gpaEnteringGradesChild11: {
    left: 187,
  },
  gpaEnteringGradesChild12: {
    left: 187,
  },
  gpaEnteringGradesChild13: {
    left: 187,
  },
  gpaEnteringGradesChild14: {
    left: 187,
  },
  gpaEnteringGradesChild15: {
    left: 187,
  },
  gpaEnteringGradesChild16: {
    left: 187,
  },
  grade: {
    top: 129,
    left: 28,
  },
  credit: {
    top: 130,
    left: 181,
  },
  lineIcon: {
    top: 138,
  },
  gpaEnteringGradesChild17: {
    top: 140,
  },
  grade1: {
    top: 180,
    left: 28,
  },
  credit1: {
    top: 181,
    left: 181,
  },
  gpaEnteringGradesChild18: {
    top: 189,
  },
  gpaEnteringGradesChild19: {
    top: 191,
  },
  grade2: {
    top: 230,
    left: 28,
  },
  credit2: {
    top: 231,
    left: 181,
  },
  gpaEnteringGradesChild20: {
    top: 239,
  },
  gpaEnteringGradesChild21: {
    top: 241,
  },
  grade3: {
    left: 28,
  },
  credit3: {
    left: 181,
  },
  gpaEnteringGradesChild22: {
    top: 291,
  },
  gpaEnteringGradesChild23: {
    top: 292,
  },
  grade4: {
    left: 28,
  },
  credit4: {
    left: 181,
  },
  gpaEnteringGradesChild24: {
    top: 342,
  },
  gpaEnteringGradesChild25: {
    top: 343,
  },
  grade5: {
    left: 28,
  },
  credit5: {
    left: 181,
  },
  gpaEnteringGradesChild26: {
    top: 392,
  },
  gpaEnteringGradesChild27: {
    top: 393,
  },
  grade6: {
    left: 28,
  },
  credit6: {
    left: 181,
  },
  gpaEnteringGradesChild28: {
    top: 442,
  },
  gpaEnteringGradesChild29: {
    top: 443,
  },
  frameIcon: {
    left: 310,
    width: 29,
    height: 16,
    top: 25,
    position: "absolute",
  },
  gpaEnteringGradesChild30: {
    top: 552,
    borderRadius: Border.br_mini,
    width: 286,
    height: 60,
    left: 38,
    position: "absolute",
  },
  frameChild: {
    height: 48,
    width: 113,
    position: "absolute",
    borderWidth: 1,
    borderColor: Color.colorBlack,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkolivegreen_200,
    borderStyle: "solid",
    borderRadius: Border.br_12xl,
  },
  submit1: {
    top: 8,
    left: 15,
    height: 33,
    width: 84,
    justifyContent: "center",
    color: Color.colorDarkseagreen,
    letterSpacing: 0.2,
    fontSize: FontSize.size_5xl,
  },
  rectangleParent: {
    height: 48,
    width: 113,
    position: "absolute",
  },
  frameView: {
    left: 124,
    top: 640,
  },
  gpaEnteringGradesChild60: {
    left: 38,
  },
  gpaEnteringGradesChild61: {
    left: 187,
  },
  grade14: {
    left: 28,
  },
  credit14: {
    left: 181,
  },
  gpaEnteringGradesChild62: {
    top: 493,
  },
  gpaEnteringGradesChild63: {
    top: 494,
  },
  gpaEnteringGradesChild68: {
    top: 226,
    left: 342,
    borderRadius: Border.br_9xs_5,
    backgroundColor: Color.colorLightgray,
    width: 7,
    height: 242,
    position: "absolute",
  },
  frameItem: {
    backgroundColor: Color.colorDarkolivegreen_300,
    left: 0,
    top: 0,
    borderRadius: Border.br_base,
    width: 94,
  },
  frameInner: {
    top: 25,
  },
  frameChild1: {
    top: 47,
  },
  frameChild2: {
    top: 69,
  },
  frameChild3: {
    top: 90,
  },
  frameChild4: {
    top: 112,
  },
  frameChild5: {
    top: 133,
  },
  s: {
    top: 7,
  },
  a: {
    top: 27,
  },
  b: {
    top: 50,
  },
  c: {
    top: 71,
    height: 17,
    width: 32,
    fontSize: FontSize.size_base,
    left: 31,
  },
  d: {
    top: 93,
  },
  e: {
    top: 114,
  },
  f: {
    top: 136,
  },
  rectangleGroup: {
    top: 167,
    left: 59,
  },
  gpaEnteringGradesChild69: {
    left: 18,
    width: 11,
    height: 18,
    top: 24,
    position: "absolute",
  },
  gpaEnteringGrades: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default GPAEnteringGrades;
