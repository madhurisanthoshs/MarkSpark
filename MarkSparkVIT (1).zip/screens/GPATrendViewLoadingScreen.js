import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const GPATrendViewLoadingScreen = () => {
  return (
    <View style={styles.gpaTrendViewLoadingScreen}>
      <View
        style={[
          styles.gpaTrendViewLoadingScreenChild,
          styles.ellipseParentPosition,
        ]}
      />
      <View
        style={[
          styles.gpaTrendViewLoadingScreenInner,
          styles.ellipseParentLayout,
        ]}
      >
        <View style={[styles.ellipseParent, styles.ellipseParentLayout]}>
          <Image
            style={styles.frameChild}
            contentFit="cover"
            source={require("../assets/ellipse-3.png")}
          />
          <Image
            style={[styles.frameItem, styles.framePosition]}
            contentFit="cover"
            source={require("../assets/line-5.png")}
          />
          <Image
            style={[styles.frameInner, styles.framePosition]}
            contentFit="cover"
            source={require("../assets/line-6.png")}
          />
          <Text style={styles.calculating}>Calculating...</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  ellipseParentPosition: {
    left: 0,
    top: 0,
  },
  ellipseParentLayout: {
    height: 159,
    width: 195,
    position: "absolute",
  },
  framePosition: {
    height: 49,
    left: 76,
    top: 9,
    position: "absolute",
  },
  gpaTrendViewLoadingScreenChild: {
    backgroundColor: Color.colorDarkslategray_100,
    width: 360,
    position: "absolute",
    left: 0,
    height: 800,
  },
  frameChild: {
    left: 63,
    width: 69,
    height: 65,
    top: 0,
    position: "absolute",
  },
  frameItem: {
    width: 43,
  },
  frameInner: {
    width: 45,
  },
  calculating: {
    top: 98,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.kumbhSansRegular,
    color: Color.colorLightgray,
    textAlign: "center",
    height: 61,
    width: 195,
    left: 0,
    position: "absolute",
  },
  ellipseParent: {
    left: 0,
    top: 0,
  },
  gpaTrendViewLoadingScreenInner: {
    top: 320,
    left: 82,
  },
  gpaTrendViewLoadingScreen: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default GPATrendViewLoadingScreen;
