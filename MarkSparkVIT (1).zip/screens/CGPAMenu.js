import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const CGPAMenu = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.cgpaMenu}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.cgpaMenuChild}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <Text style={styles.cgpa}>CGPA</Text>
      <View style={[styles.cgpaMenuItem, styles.cgpaShadowBox]} />
      <Text style={[styles.cgpaPredictor, styles.cgpaTypo]}>
        CGPA predictor
      </Text>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        onPress={() => navigation.navigate("CGPAMainScreen")}
        containerStyle={styles.lineIconBtn}
        buttonStyle={styles.lineIconBtn1}
      />
      <View style={[styles.cgpaMenuInner, styles.cgpaShadowBox]} />
      <Text style={[styles.cgpaTrendViewer, styles.cgpaTypo]}>
        CGPA trend viewer
      </Text>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        onPress={() => navigation.navigate("CGPATrendView")}
        containerStyle={styles.lineIcon1Btn}
        buttonStyle={styles.lineIcon1Btn1}
      />
      <View style={[styles.rectangleView, styles.rectangleViewPosition]} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa1, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={[styles.cgpaMenuChild1, styles.rectangleViewPosition]} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa1, styles.gpaFlexBox]}>CGPA</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  lineIconBtn: {
    left: 310,
    top: 285,
    position: "absolute",
  },
  lineIconBtn1: {
    borderStyle: "solid",
    width: 12,
    height: 19,
    backgroundColor: "#C3CFB7",
  },
  lineIcon1Btn: {
    left: 310,
    top: 392,
    position: "absolute",
  },
  lineIcon1Btn1: {
    borderStyle: "solid",
    width: 12,
    height: 19,
    backgroundColor: "#C3CFB7",
  },
  cgpaShadowBox: {
    height: 81,
    width: 331,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_lgi,
    left: 15,
    position: "absolute",
  },
  cgpaTypo: {
    height: 75,
    color: Color.colorLightgray,
    left: 45,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  rectangleViewPosition: {
    height: 90,
    width: 360,
    left: 0,
    top: 710,
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    justifyContent: "center",
    fontFamily: FontFamily.kumbhSansRegular,
    letterSpacing: 0.2,
    fontSize: FontSize.size_mini,
    top: 766,
    color: Color.colorLightgray,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout2: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconLayout: {
    flexDirection: "row",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  marksparkVit: {
    top: 29,
    left: 82,
    fontWeight: "300",
    fontFamily: FontFamily.comfortaaLight,
    color: Color.colorGainsboro_100,
    textAlign: "center",
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  cgpaMenuChild: {
    top: 33,
    left: 294,
    width: 29,
    height: 16,
    position: "absolute",
  },
  cgpa: {
    top: 130,
    fontSize: FontSize.size_8xl,
    color: Color.colorWhite,
    width: 216,
    height: 47,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    left: 15,
    position: "absolute",
  },
  cgpaMenuItem: {
    top: 254,
  },
  cgpaPredictor: {
    top: 257,
    width: 193,
  },
  cgpaMenuInner: {
    top: 361,
  },
  cgpaTrendViewer: {
    top: 364,
    width: 212,
  },
  rectangleView: {
    backgroundColor: Color.colorDarkslategray_200,
  },
  home: {
    left: 6,
  },
  grades: {
    left: 96,
  },
  gpa: {
    left: 186,
  },
  cgpa1: {
    left: 276,
  },
  vectorIcon: {
    right: "81.11%",
    left: "6.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.94%",
    left: "57.22%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.94%",
    left: "81.94%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.56%",
    left: "30.83%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  cgpaMenuChild1: {
    backgroundColor: Color.colorDarkslategray_100,
    undefined: "",
  },
  cgpaMenu: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default CGPAMenu;
