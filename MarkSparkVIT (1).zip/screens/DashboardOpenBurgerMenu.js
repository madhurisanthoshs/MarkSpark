import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const DashboardOpenBurgerMenu = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.dashboardOpenBurgerMenu}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <View
        style={[styles.dashboardOpenBurgerMenuChild, styles.dashboardPosition]}
      />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <Image
        style={styles.dashboardPosition}
        contentFit="cover"
        source={require("../assets/rectangle-8.png")}
      />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={styles.helloAnirudhTContainer}>
        <Text style={styles.helloAnirudhTContainer1}>
          <Text style={styles.hello}>{`Hello, 
`}</Text>
          <Text style={styles.anirudhT}>Anirudh T</Text>
        </Text>
      </Text>
      <View
        style={[
          styles.dashboardOpenBurgerMenuInner,
          styles.dashboardChildShadowBox,
        ]}
      />
      <Text style={styles.creditsCompleted}>
        <Text style={styles.helloAnirudhTContainer1}>
          <Text style={styles.text}>{`108.5/150
`}</Text>
          <Text style={styles.creditsCompleted1}>{`Credits 
Completed`}</Text>
        </Text>
      </Text>
      <View style={[styles.rectangleView, styles.dashboardChildShadowBox]} />
      <Text style={[styles.yn, styles.ynPosition]}>yn</Text>
      <Text style={styles.youreDoingGreat}>
        You’re doing great, hang in there!
      </Text>
      <Text style={styles.helloAnirudhTContainer}>
        <Text style={styles.helloAnirudhTContainer1}>
          <Text style={styles.hello}>{`Hello, 
`}</Text>
          <Text style={styles.anirudhT}>Anirudh T</Text>
        </Text>
      </Text>
      <View
        style={[
          styles.dashboardOpenBurgerMenuChild1,
          styles.dashboardChildShadowBox,
        ]}
      />
      <Text style={styles.creditsCompleted}>
        <Text style={styles.helloAnirudhTContainer1}>
          <Text style={styles.text}>{`108.5/150
`}</Text>
          <Text style={styles.creditsCompleted1}>{`Credits 
Completed`}</Text>
        </Text>
      </Text>
      <View
        style={[
          styles.dashboardOpenBurgerMenuChild2,
          styles.dashboardChildShadowBox,
        ]}
      />
      <Text style={[styles.cgpa2, styles.ynPosition]}>
        <Text style={styles.helloAnirudhTContainer1}>
          <Text style={styles.text2}>{`8.70
`}</Text>
          <Text style={styles.creditsCompleted1}>CGPA</Text>
        </Text>
      </Text>
      <Text style={styles.youreDoingGreat} numberOfLines={2}>
        You’re doing great, hang in there!
      </Text>
      <View style={styles.dashboardOpenBurgerMenuChild3} />
      <Image
        style={[styles.frameIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/frame-27.png")}
      />
      <View style={[styles.lineView, styles.lineViewLayout]} />
      <View
        style={[styles.dashboardOpenBurgerMenuChild4, styles.lineViewLayout]}
      />
      <View style={styles.sync}>
        <Pressable
          style={[styles.sync1, styles.sync1Position]}
          onPress={() => navigation.goBack()}
        >
          <Text style={[styles.sync2, styles.sync2Typo]}>Sync</Text>
        </Pressable>
        <Image
          style={[styles.vectorIcon8, styles.vectorIconPosition]}
          contentFit="cover"
          source={require("../assets/vector4.png")}
        />
      </View>
      <View style={styles.logout}>
        <Text style={[styles.logout1, styles.sync2Typo]}>Logout</Text>
        <Image
          style={[styles.vectorIcon9, styles.vectorIconPosition]}
          contentFit="cover"
          source={require("../assets/vector5.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  dashboardPosition: {
    height: 90,
    width: 360,
    left: 0,
    top: 710,
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    color: Color.colorLightgray,
    letterSpacing: 0.2,
    top: 766,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansRegular,
    fontSize: FontSize.size_mini,
    textAlign: "center",
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    position: "absolute",
  },
  vectorIconLayout: {
    flexDirection: "row",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  dashboardChildShadowBox: {
    height: 151,
    width: 157,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_lgi,
    top: 294,
    position: "absolute",
  },
  ynPosition: {
    height: 132,
    width: 137,
    left: 25,
    top: 305,
    color: Color.colorDarkseagreen,
    textAlign: "left",
    alignItems: "center",
    display: "flex",
    position: "absolute",
  },
  lineViewLayout: {
    height: 2,
    width: 31,
    borderTopWidth: 2,
    borderColor: Color.colorGainsboro_100,
    left: 315,
    borderStyle: "solid",
    position: "absolute",
  },
  sync1Position: {
    top: 0,
    position: "absolute",
  },
  sync2Typo: {
    width: 120,
    height: 31,
    textAlign: "left",
    alignItems: "center",
    display: "flex",
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
    letterSpacing: 0.2,
    fontSize: FontSize.size_mini,
  },
  vectorIconPosition: {
    left: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  marksparkVit: {
    top: 51,
    left: 92,
    fontSize: FontSize.size_xl,
    letterSpacing: 1.8,
    lineHeight: 24,
    fontFamily: FontFamily.comfortaaLight,
    color: Color.colorWhite,
    textAlign: "center",
    fontWeight: "300",
    position: "absolute",
  },
  dashboardOpenBurgerMenuChild: {
    backgroundColor: Color.colorDarkslategray_200,
  },
  home: {
    left: 6,
  },
  grades: {
    left: 96,
  },
  gpa: {
    left: 186,
  },
  cgpa: {
    left: 276,
  },
  vectorIcon: {
    right: "81.11%",
    left: "6.11%",
    maxWidth: "100%",
    bottom: "4.88%",
    maxHeight: "100%",
    overflow: "hidden",
    top: "90.13%",
    height: "5%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.94%",
    left: "57.22%",
    width: "10.83%",
    maxWidth: "100%",
    bottom: "4.88%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  vectorIcon2: {
    right: "6.94%",
    left: "81.94%",
    width: "11.11%",
    maxWidth: "100%",
    bottom: "4.88%",
    maxHeight: "100%",
    overflow: "hidden",
    top: "90.13%",
    height: "5%",
  },
  vectorIcon3: {
    right: "55.56%",
    left: "30.83%",
    width: "13.61%",
    maxWidth: "100%",
    bottom: "4.88%",
    maxHeight: "100%",
    overflow: "hidden",
    top: "90.13%",
    height: "5%",
  },
  hello: {
    fontSize: FontSize.size_13xl,
    fontFamily: FontFamily.kumbhSansRegular,
  },
  anirudhT: {
    fontSize: FontSize.size_29xl,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
  },
  helloAnirudhTContainer1: {
    width: "100%",
  },
  helloAnirudhTContainer: {
    top: 124,
    color: Color.colorGainsboro_100,
    width: 289,
    height: 123,
    textAlign: "left",
    left: 14,
    alignItems: "center",
    display: "flex",
    position: "absolute",
  },
  dashboardOpenBurgerMenuInner: {
    left: 188,
  },
  text: {
    fontSize: FontSize.size_24xl,
  },
  creditsCompleted1: {
    fontSize: FontSize.size_mini,
  },
  creditsCompleted: {
    top: 304,
    left: 200,
    width: 133,
    height: 130,
    color: Color.colorDarkseagreen,
    textAlign: "left",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansRegular,
    position: "absolute",
  },
  rectangleView: {
    left: 14,
    width: 157,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_lgi,
    top: 294,
  },
  yn: {
    letterSpacing: 0.3,
    fontFamily: FontFamily.comfortaaRegular,
    fontSize: FontSize.size_13xl,
  },
  youreDoingGreat: {
    top: 523,
    left: 15,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.kumbhSansLight,
    color: Color.colorDarkolivegreen_100,
    width: 331,
    height: 99,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    fontWeight: "300",
    position: "absolute",
  },
  dashboardOpenBurgerMenuChild1: {
    left: 188,
  },
  dashboardOpenBurgerMenuChild2: {
    left: 14,
    width: 157,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_lgi,
    top: 294,
  },
  text2: {
    fontSize: FontSize.size_36xl,
  },
  cgpa2: {
    fontFamily: FontFamily.kumbhSansRegular,
  },
  dashboardOpenBurgerMenuChild3: {
    top: 43,
    left: 174,
    borderRadius: 9,
    backgroundColor: Color.colorDarkslategray_100,
    width: 179,
    height: 142,
    position: "absolute",
  },
  frameIcon: {
    top: 59,
    left: 316,
    width: 29,
  },
  lineView: {
    top: 66,
  },
  dashboardOpenBurgerMenuChild4: {
    top: 74,
  },
  sync2: {
    height: 31,
  },
  sync1: {
    left: 40,
  },
  vectorIcon8: {
    height: "97.14%",
    width: "15%",
    top: "2.86%",
    right: "85%",
    bottom: "0%",
  },
  sync: {
    top: 86,
    left: 189,
    width: 160,
    height: 35,
    position: "absolute",
  },
  logout1: {
    left: 41,
    height: 31,
    top: 0,
    position: "absolute",
  },
  vectorIcon9: {
    height: "83.87%",
    width: "15.53%",
    top: "6.45%",
    right: "84.47%",
    bottom: "9.68%",
  },
  logout: {
    top: 132,
    width: 161,
    height: 31,
    left: 188,
    position: "absolute",
  },
  dashboardOpenBurgerMenu: {
    backgroundColor: Color.colorGray,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default DashboardOpenBurgerMenu;
