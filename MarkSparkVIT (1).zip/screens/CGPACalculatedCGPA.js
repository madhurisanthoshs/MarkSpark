import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import CalculatedCGPA from "../components/CalculatedCGPA";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const CGPACalculatedCGPA = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.cgpaCalculatedCgpa}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.cgpaCalculatedCgpaChild}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <Text style={styles.cgpaPredictor}>CGPA Predictor</Text>
      <View style={[styles.cgpaCalculatedCgpaItem, styles.cgpaShadowBox]} />
      <Text style={[styles.text, styles.textTypo]}>103.5</Text>
      <View style={[styles.cgpaCalculatedCgpaInner, styles.cgpaShadowBox]} />
      <Text style={[styles.text1, styles.textTypo]}>20.5</Text>
      <View style={[styles.rectangleView, styles.cgpaShadowBox]} />
      <Text style={[styles.text2, styles.textTypo]}>9.5</Text>
      <View style={[styles.cgpaCalculatedCgpaChild1, styles.cgpaShadowBox]} />
      <Text style={[styles.text3, styles.textTypo]}>8.7</Text>
      <View style={styles.cgpaCalculatedCgpaChild2} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.cgpaCalculatedCgpaChild2} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={styles.cgpaCalculatedCgpaChild2} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.cgpaCalculatedCgpaChild2} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.cgpaCalculatedCgpaChild6} />
      <CalculatedCGPA />
      <Button
        title="Submit"
        radius={5}
        iconPosition="left"
        type="solid"
        titleStyle={styles.frameButtonBtn}
        onPress={() => navigation.navigate("CGPALoadingScreen")}
        containerStyle={styles.frameButtonBtn1}
        buttonStyle={styles.frameButtonBtn2}
      />
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        onPress={() =>
          navigation.navigate("BottomTabsRoot", { screen: "CGPAMenu" })
        }
        containerStyle={styles.lineIconBtn}
        buttonStyle={styles.lineIconBtn1}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  frameButtonBtn: {
    color: "#b4d99a",
    fontSize: 24,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  frameButtonBtn1: {
    left: 124,
    top: 612,
    position: "absolute",
  },
  frameButtonBtn2: {
    width: 113,
    height: 48,
    backgroundColor: "#395922",
    borderRadius: 100,
  },
  lineIconBtn: {
    left: 18,
    top: 24,
    position: "absolute",
  },
  lineIconBtn1: {
    borderStyle: "solid",
    width: 11,
    height: 18,
    backgroundColor: "#C3CFB7",
  },
  cgpaShadowBox: {
    height: 62,
    width: 330,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_12xl,
    left: 15,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  textTypo: {
    height: 41,
    width: 298,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansLight,
    letterSpacing: 0.2,
    left: 32,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontWeight: "300",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    justifyContent: "center",
    fontFamily: FontFamily.kumbhSansRegular,
    fontSize: FontSize.size_mini,
    top: 766,
    color: Color.colorLightgray,
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout2: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconLayout: {
    flexDirection: "row",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  marksparkVit: {
    top: 23,
    left: 80,
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    color: Color.colorWhite,
    fontWeight: "300",
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  cgpaCalculatedCgpaChild: {
    top: 25,
    left: 310,
    width: 29,
    height: 16,
    position: "absolute",
  },
  cgpaPredictor: {
    top: 88,
    left: 18,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
    width: 204,
    height: 39,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  cgpaCalculatedCgpaItem: {
    top: 155,
  },
  text: {
    top: 166,
  },
  cgpaCalculatedCgpaInner: {
    top: 313,
  },
  text1: {
    top: 324,
  },
  rectangleView: {
    top: 390,
  },
  text2: {
    top: 401,
  },
  cgpaCalculatedCgpaChild1: {
    top: 234,
  },
  text3: {
    top: 245,
  },
  cgpaCalculatedCgpaChild2: {
    top: 710,
    left: 0,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    position: "absolute",
  },
  home: {
    left: 6,
  },
  grades: {
    left: 96,
  },
  gpa: {
    left: 186,
  },
  cgpa: {
    left: 276,
  },
  vectorIcon: {
    right: "81.11%",
    left: "6.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.94%",
    left: "57.22%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.94%",
    left: "81.94%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.56%",
    left: "30.83%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  cgpaCalculatedCgpaChild6: {
    top: 502,
    left: 37,
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorDarkolivegreen_200,
    width: 286,
    height: 60,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  cgpaCalculatedCgpa: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default CGPACalculatedCGPA;
