import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button as RNPButton } from "react-native-paper";
import { Button } from "@rneui/themed";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const GPAEnteringCredits = () => {
  return (
    <View style={styles.gpaEnteringCredits}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <View style={[styles.gpaEnteringCreditsChild, styles.gpaLayout]} />
      <View style={[styles.gpaEnteringCreditsItem, styles.gpaLayout]} />
      <View style={[styles.gpaEnteringCreditsInner, styles.gpaLayout]} />
      <Text style={styles.gpaPredictor}>GPA predictor</Text>
      <View style={[styles.rectangleView, styles.rectangleViewShadowBox]} />
      <Text style={styles.submit}>Submit</Text>
      <View style={styles.gpaEnteringCreditsChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <View style={styles.gpaEnteringCreditsChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={[styles.gpaEnteringCreditsChild3, styles.gpaChildLayout8]} />
      <View style={[styles.gpaEnteringCreditsChild4, styles.gpaChildLayout7]} />
      <View style={[styles.gpaEnteringCreditsChild5, styles.gpaChildLayout6]} />
      <View style={[styles.gpaEnteringCreditsChild6, styles.gpaChildLayout5]} />
      <View style={[styles.gpaEnteringCreditsChild7, styles.gpaChildLayout4]} />
      <View style={[styles.gpaEnteringCreditsChild8, styles.gpaChildLayout3]} />
      <View style={[styles.gpaEnteringCreditsChild9, styles.gpaChildLayout2]} />
      <View
        style={[styles.gpaEnteringCreditsChild10, styles.gpaChildLayout8]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild11, styles.gpaChildLayout7]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild12, styles.gpaChildLayout6]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild13, styles.gpaChildLayout5]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild14, styles.gpaChildLayout4]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild15, styles.gpaChildLayout3]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild16, styles.gpaChildLayout2]}
      />
      <Text style={[styles.grade, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.lineIcon, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild17, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade1, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit1, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild18, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild19, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade2, styles.gradeTypo]}>Grade</Text>
      <Text style={[styles.credit2, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild20, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild21, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade3, styles.grade3Typo]}>Grade</Text>
      <Text style={[styles.credit3, styles.grade3Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild22, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild23, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade4, styles.grade4Typo]}>Grade</Text>
      <Text style={[styles.credit4, styles.grade4Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild24, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild25, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade5, styles.grade5Typo]}>Grade</Text>
      <Text style={[styles.credit5, styles.grade5Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild26, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild27, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade6, styles.grade6Typo]}>Grade</Text>
      <Text style={[styles.credit6, styles.grade6Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild28, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild29, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.frameIcon}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <Text style={styles.gpaPredictor}>GPA predictor</Text>
      <View
        style={[
          styles.gpaEnteringCreditsChild30,
          styles.rectangleViewShadowBox,
        ]}
      />
      <RNPButton
        style={[styles.frameRnpbutton, styles.rectangleViewPosition]}
        mode="contained"
        labelStyle={styles.frameButtonBtn}
        contentStyle={styles.frameButtonBtn1}
      >
        Submit
      </RNPButton>
      <View style={styles.gpaEnteringCreditsChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <View style={styles.gpaEnteringCreditsChild1} />
      <Text style={[styles.home, styles.gpaTypo]}>Home</Text>
      <Text style={[styles.gpa, styles.gpaTypo]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaTypo]}>CGPA</Text>
      <Text style={[styles.grades, styles.gpaTypo]}>Grades</Text>
      <View style={[styles.gpaEnteringCreditsChild3, styles.gpaChildLayout8]} />
      <View style={[styles.gpaEnteringCreditsChild4, styles.gpaChildLayout7]} />
      <View style={[styles.gpaEnteringCreditsChild5, styles.gpaChildLayout6]} />
      <View style={[styles.gpaEnteringCreditsChild6, styles.gpaChildLayout5]} />
      <View style={[styles.gpaEnteringCreditsChild7, styles.gpaChildLayout4]} />
      <View style={[styles.gpaEnteringCreditsChild8, styles.gpaChildLayout3]} />
      <View style={[styles.gpaEnteringCreditsChild9, styles.gpaChildLayout2]} />
      <View
        style={[styles.gpaEnteringCreditsChild10, styles.gpaChildLayout8]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild11, styles.gpaChildLayout7]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild12, styles.gpaChildLayout6]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild13, styles.gpaChildLayout5]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild14, styles.gpaChildLayout4]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild15, styles.gpaChildLayout3]}
      />
      <View
        style={[styles.gpaEnteringCreditsChild16, styles.gpaChildLayout2]}
      />
      <Text style={[styles.grade, styles.gradeTypo]}>S</Text>
      <Text style={[styles.credit, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.lineIcon, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild17, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade1, styles.gradeTypo]}>B</Text>
      <Text style={[styles.credit1, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild18, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild19, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade2, styles.gradeTypo]}>A</Text>
      <Text style={[styles.credit2, styles.gradeTypo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild20, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild21, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade3, styles.grade3Typo]}>Grade</Text>
      <Text style={[styles.credit3, styles.grade3Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild22, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild23, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade4, styles.grade4Typo]}>Grade</Text>
      <Text style={[styles.credit4, styles.grade4Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild24, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild25, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade5, styles.grade5Typo]}>Grade</Text>
      <Text style={[styles.credit5, styles.grade5Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild26, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild27, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Text style={[styles.grade6, styles.grade6Typo]}>Grade</Text>
      <Text style={[styles.credit6, styles.grade6Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild28, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild29, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <View style={[styles.gpaEnteringCreditsChild61, styles.gpaChildLayout]} />
      <View style={[styles.gpaEnteringCreditsChild62, styles.gpaChildLayout]} />
      <Text style={[styles.grade11, styles.grade11Typo]}>Grade</Text>
      <Text style={[styles.credit14, styles.grade11Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild63, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild64, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <View style={[styles.gpaEnteringCreditsChild61, styles.gpaChildLayout]} />
      <View style={[styles.gpaEnteringCreditsChild62, styles.gpaChildLayout]} />
      <Text style={[styles.grade11, styles.grade11Typo]}>Grade</Text>
      <Text style={[styles.credit14, styles.grade11Typo]}>Credit</Text>
      <Image
        style={[styles.gpaEnteringCreditsChild63, styles.gpaChildLayout1]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <Image
        style={[styles.gpaEnteringCreditsChild64, styles.gpaChildPosition]}
        contentFit="cover"
        source={require("../assets/line-4.png")}
      />
      <View style={styles.gpaEnteringCreditsChild69} />
      <View style={styles.rectangleParent}>
        <View style={styles.frameChild} />
        <Image
          style={[styles.frameItem, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-61.png")}
        />
        <Image
          style={[styles.frameInner, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-9.png")}
        />
        <Image
          style={[styles.frameChild1, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-7.png")}
        />
        <Image
          style={[styles.frameChild2, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-8.png")}
        />
        <Text style={[styles.text, styles.textTypo]}>1</Text>
        <Text style={[styles.text1, styles.textTypo]}>1.5</Text>
        <Text style={[styles.text2, styles.textTypo]}>2</Text>
        <Text style={[styles.text3, styles.textTypo]}>3</Text>
        <Text style={[styles.text4, styles.textTypo]}>4</Text>
      </View>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        containerStyle={styles.lineIcon32Btn}
        buttonStyle={styles.lineIcon32Btn1}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  frameButtonBtn: {
    color: "#b4d99a",
    fontSize: 24,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  frameButtonBtn1: {
    height: 48,
    width: 113,
  },
  lineIcon32Btn: {
    left: 18,
    top: 24,
    position: "absolute",
  },
  lineIcon32Btn1: {
    borderStyle: "solid",
    width: 11,
    height: 18,
  },
  gpaLayout: {
    height: 2,
    width: 31,
    borderTopWidth: 2,
    borderColor: Color.colorGainsboro_100,
    borderStyle: "solid",
    left: 309,
    position: "absolute",
  },
  rectangleViewShadowBox: {
    borderWidth: 1,
    borderColor: Color.colorBlack,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkolivegreen_200,
    borderStyle: "solid",
    position: "absolute",
  },
  gpaTypo: {
    height: 34,
    width: 78,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
    fontSize: FontSize.size_mini,
    top: 766,
    justifyContent: "center",
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout2: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  gpaChildLayout8: {
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    top: 126,
    height: 39,
    position: "absolute",
  },
  gpaChildLayout7: {
    height: 38,
    top: 177,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    position: "absolute",
  },
  gpaChildLayout6: {
    top: 227,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    height: 39,
    position: "absolute",
  },
  gpaChildLayout5: {
    top: 278,
    height: 38,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    position: "absolute",
  },
  gpaChildLayout4: {
    top: 328,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    height: 39,
    position: "absolute",
  },
  gpaChildLayout3: {
    top: 379,
    height: 38,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    position: "absolute",
  },
  gpaChildLayout2: {
    top: 429,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    height: 39,
    position: "absolute",
  },
  gradeTypo: {
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  gpaChildLayout1: {
    height: 13,
    width: 19,
    left: 130,
    position: "absolute",
  },
  gpaChildPosition: {
    left: 284,
    height: 13,
    width: 19,
    position: "absolute",
  },
  grade3Typo: {
    top: 282,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  grade4Typo: {
    top: 333,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  grade5Typo: {
    top: 383,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  grade6Typo: {
    top: 433,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  rectangleViewPosition: {
    left: 124,
    top: 640,
  },
  vectorIconLayout: {
    flexDirection: "row",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  gpaChildLayout: {
    top: 480,
    width: 137,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_base,
    height: 39,
    position: "absolute",
  },
  grade11Typo: {
    top: 484,
    height: 31,
    width: 121,
    letterSpacing: 0.1,
    fontSize: FontSize.size_sm,
    color: Color.colorLightgray,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  frameChildLayout: {
    height: 1,
    left: 0,
    width: 94,
    position: "absolute",
  },
  textTypo: {
    height: 17,
    width: 32,
    fontSize: FontSize.size_base,
    color: Color.colorLightgray,
    justifyContent: "center",
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  marksparkVit: {
    top: 23,
    left: 80,
    fontWeight: "300",
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  gpaEnteringCreditsChild: {
    top: 24,
  },
  gpaEnteringCreditsItem: {
    top: 32,
  },
  gpaEnteringCreditsInner: {
    top: 40,
  },
  gpaPredictor: {
    left: 15,
    textAlign: "left",
    width: 204,
    height: 39,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    top: 71,
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  rectangleView: {
    borderRadius: Border.br_12xl,
    width: 113,
    height: 48,
    left: 124,
    top: 640,
  },
  submit: {
    top: 648,
    left: 139,
    fontSize: FontSize.size_5xl,
    color: Color.colorDarkseagreen,
    width: 84,
    height: 33,
    justifyContent: "center",
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  gpaEnteringCreditsChild1: {
    top: 710,
    left: 1,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    position: "absolute",
  },
  home: {
    left: 7,
  },
  grades: {
    left: 97,
  },
  gpa: {
    left: 187,
  },
  cgpa: {
    left: 277,
  },
  vectorIcon: {
    right: "80.83%",
    left: "6.39%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.67%",
    left: "57.5%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.67%",
    left: "82.22%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.28%",
    left: "31.11%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  gpaEnteringCreditsChild3: {
    left: 38,
  },
  gpaEnteringCreditsChild4: {
    left: 38,
  },
  gpaEnteringCreditsChild5: {
    left: 38,
  },
  gpaEnteringCreditsChild6: {
    left: 38,
  },
  gpaEnteringCreditsChild7: {
    left: 38,
  },
  gpaEnteringCreditsChild8: {
    left: 38,
  },
  gpaEnteringCreditsChild9: {
    left: 38,
  },
  gpaEnteringCreditsChild10: {
    left: 187,
  },
  gpaEnteringCreditsChild11: {
    left: 187,
  },
  gpaEnteringCreditsChild12: {
    left: 187,
  },
  gpaEnteringCreditsChild13: {
    left: 187,
  },
  gpaEnteringCreditsChild14: {
    left: 187,
  },
  gpaEnteringCreditsChild15: {
    left: 187,
  },
  gpaEnteringCreditsChild16: {
    left: 187,
  },
  grade: {
    top: 129,
    left: 28,
  },
  credit: {
    top: 130,
    left: 181,
  },
  lineIcon: {
    top: 138,
  },
  gpaEnteringCreditsChild17: {
    top: 140,
  },
  grade1: {
    top: 180,
    left: 28,
  },
  credit1: {
    top: 181,
    left: 181,
  },
  gpaEnteringCreditsChild18: {
    top: 189,
  },
  gpaEnteringCreditsChild19: {
    top: 191,
  },
  grade2: {
    top: 230,
    left: 28,
  },
  credit2: {
    top: 231,
    left: 181,
  },
  gpaEnteringCreditsChild20: {
    top: 239,
  },
  gpaEnteringCreditsChild21: {
    top: 241,
  },
  grade3: {
    left: 28,
  },
  credit3: {
    left: 181,
  },
  gpaEnteringCreditsChild22: {
    top: 291,
  },
  gpaEnteringCreditsChild23: {
    top: 292,
  },
  grade4: {
    left: 28,
  },
  credit4: {
    left: 181,
  },
  gpaEnteringCreditsChild24: {
    top: 342,
  },
  gpaEnteringCreditsChild25: {
    top: 343,
  },
  grade5: {
    left: 28,
  },
  credit5: {
    left: 181,
  },
  gpaEnteringCreditsChild26: {
    top: 392,
  },
  gpaEnteringCreditsChild27: {
    top: 393,
  },
  grade6: {
    left: 28,
  },
  credit6: {
    left: 181,
  },
  gpaEnteringCreditsChild28: {
    top: 442,
  },
  gpaEnteringCreditsChild29: {
    top: 443,
  },
  frameIcon: {
    top: 25,
    left: 310,
    width: 29,
    height: 16,
    position: "absolute",
  },
  gpaEnteringCreditsChild30: {
    top: 552,
    borderRadius: Border.br_mini,
    width: 286,
    height: 60,
    left: 38,
  },
  frameRnpbutton: {
    borderRadius: 100,
    backgroundColor: "#395922",
    position: "absolute",
  },
  gpaEnteringCreditsChild61: {
    left: 38,
  },
  gpaEnteringCreditsChild62: {
    left: 187,
  },
  grade11: {
    left: 28,
  },
  credit14: {
    left: 181,
  },
  gpaEnteringCreditsChild63: {
    top: 493,
  },
  gpaEnteringCreditsChild64: {
    top: 494,
  },
  gpaEnteringCreditsChild69: {
    top: 222,
    left: 341,
    borderRadius: Border.br_9xs_5,
    backgroundColor: Color.colorLightgray,
    width: 7,
    height: 242,
    position: "absolute",
  },
  frameChild: {
    backgroundColor: Color.colorDarkolivegreen_300,
    height: 115,
    zIndex: 0,
    width: 94,
    borderRadius: Border.br_base,
  },
  frameItem: {
    top: 47,
    zIndex: 1,
  },
  frameInner: {
    zIndex: 2,
    top: 24,
  },
  frameChild1: {
    top: 69,
    zIndex: 3,
  },
  frameChild2: {
    top: 90,
    zIndex: 4,
  },
  text: {
    top: 7,
    zIndex: 5,
    left: 31,
    height: 17,
    width: 32,
    fontSize: FontSize.size_base,
  },
  text1: {
    top: 27,
    zIndex: 6,
    left: 31,
    height: 17,
    width: 32,
    fontSize: FontSize.size_base,
  },
  text2: {
    top: 50,
    zIndex: 7,
    left: 31,
    height: 17,
    width: 32,
    fontSize: FontSize.size_base,
  },
  text3: {
    zIndex: 8,
    left: 31,
    height: 17,
    width: 32,
    fontSize: FontSize.size_base,
    top: 71,
  },
  text4: {
    top: 93,
    left: 30,
    zIndex: 9,
  },
  rectangleParent: {
    top: 167,
    left: 209,
    position: "absolute",
  },
  gpaEnteringCredits: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default GPAEnteringCredits;
