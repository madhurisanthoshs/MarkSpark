import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const GradeHistoryMenu = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.gradeHistoryMenu}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.gradeHistoryMenuChild}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <Text style={styles.gradeHistory}>Grade History</Text>
      <View style={[styles.gradeHistoryMenuItem, styles.gradeShadowBox]} />
      <Text style={[styles.effectiveGrades, styles.distributionTypo]}>
        Effective Grades
      </Text>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        color="#c3cfb7"
        onPress={() => navigation.navigate("EffectiveGradeHistory")}
        containerStyle={styles.lineIconBtn}
        buttonStyle={styles.lineIconBtn1}
      />
      <View style={[styles.gradeHistoryMenuInner, styles.gradeShadowBox]} />
      <Text style={[styles.curriculumDistribution, styles.distributionTypo]}>
        Curriculum Distribution
      </Text>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        color="#c3cfb7"
        onPress={() => navigation.navigate("CurriculumDistribution")}
        containerStyle={styles.lineIcon1Btn}
        buttonStyle={styles.lineIcon1Btn1}
      />
      <View style={[styles.rectangleView, styles.gradeShadowBox]} />
      <Text style={[styles.gradeDistribution, styles.distributionTypo]}>
        Grade distribution
      </Text>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        color="#c3cfb7"
        onPress={() => navigation.navigate("GradeDistribution")}
        containerStyle={styles.lineIcon2Btn}
        buttonStyle={styles.lineIcon2Btn1}
      />
      <View style={styles.gradeHistoryMenuChild1} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={styles.gradeHistoryMenuChild1} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  lineIconBtn: {
    left: 310,
    top: 284,
    position: "absolute",
  },
  lineIconBtn1: {
    borderStyle: "solid",
    width: 12,
    height: 19,
  },
  lineIcon1Btn: {
    left: 310,
    top: 391,
    position: "absolute",
  },
  lineIcon1Btn1: {
    borderStyle: "solid",
    width: 12,
    height: 19,
  },
  lineIcon2Btn: {
    left: 310,
    top: 498,
    position: "absolute",
  },
  lineIcon2Btn1: {
    borderStyle: "solid",
    width: 12,
    height: 19,
  },
  gradeShadowBox: {
    height: 81,
    width: 331,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_lgi,
    left: 15,
    position: "absolute",
  },
  distributionTypo: {
    height: 75,
    width: 193,
    color: Color.colorLightgray,
    left: 45,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    justifyContent: "center",
    fontFamily: FontFamily.kumbhSansRegular,
    letterSpacing: 0.2,
    fontSize: FontSize.size_mini,
    top: 766,
    color: Color.colorLightgray,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorFlexBox: {
    flexDirection: "row",
    backgroundColor: Color.colorLightgray,
  },
  marksparkVit: {
    top: 29,
    left: 82,
    fontWeight: "300",
    fontFamily: FontFamily.comfortaaLight,
    color: Color.colorGainsboro_100,
    textAlign: "center",
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  gradeHistoryMenuChild: {
    top: 33,
    left: 294,
    width: 29,
    height: 16,
    position: "absolute",
  },
  gradeHistory: {
    top: 130,
    fontSize: FontSize.size_8xl,
    color: Color.colorWhite,
    width: 216,
    height: 47,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    left: 15,
    position: "absolute",
  },
  gradeHistoryMenuItem: {
    top: 253,
  },
  effectiveGrades: {
    top: 256,
  },
  gradeHistoryMenuInner: {
    top: 360,
  },
  curriculumDistribution: {
    top: 363,
  },
  rectangleView: {
    top: 467,
  },
  gradeDistribution: {
    top: 470,
  },
  gradeHistoryMenuChild1: {
    top: 710,
    left: 0,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    position: "absolute",
  },
  home: {
    left: 6,
  },
  grades: {
    left: 96,
  },
  gpa: {
    left: 186,
  },
  cgpa: {
    left: 276,
  },
  vectorIcon: {
    right: "81.11%",
    left: "6.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.94%",
    left: "57.22%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.94%",
    left: "81.94%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.56%",
    left: "30.83%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  gradeHistoryMenu: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default GradeHistoryMenu;
