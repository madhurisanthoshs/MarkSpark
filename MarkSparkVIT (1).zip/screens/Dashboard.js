import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import CreditValue from "../components/CreditValue";
import CurrentCGPA from "../components/CurrentCGPA";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const Dashboard = () => {
  return (
    <View style={styles.dashboard}>
      <View style={[styles.dashboardChild, styles.dashboardLayout]} />
      <View style={[styles.dashboardItem, styles.dashboardLayout]} />
      <View style={[styles.dashboardInner, styles.dashboardLayout]} />
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.frameIcon}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <View style={styles.frame}>
        <Text style={styles.helloAnirudhTContainer}>
          <Text style={styles.helloAnirudhTContainer1}>
            <Text style={styles.hello}>{`Hello, 
`}</Text>
            <Text style={styles.anirudhT}>Anirudh T</Text>
          </Text>
        </Text>
        <Text style={styles.helloAnirudhTContainer}>
          <Text style={styles.helloAnirudhTContainer1}>
            <Text style={styles.hello}>{`Hello, 
`}</Text>
            <Text style={styles.anirudhT}>Anirudh T</Text>
          </Text>
        </Text>
      </View>
      <View style={styles.frame1}>
        <View style={[styles.frameChild, styles.frameLayout]} />
        <Text style={[styles.creditsCompleted, styles.cgpaTypo]}>
          <Text style={styles.helloAnirudhTContainer1}>
            <Text style={styles.text}>{`108.5/150
`}</Text>
            <Text style={styles.creditsCompleted1}>{`Credits 
Completed`}</Text>
          </Text>
        </Text>
        <View style={[styles.frameItem, styles.frameLayout]} />
        <Text style={[styles.cgpa, styles.cgpaTypo]}>
          <Text style={styles.helloAnirudhTContainer1}>
            <Text style={styles.text1}>{`8.70
`}</Text>
            <Text style={styles.creditsCompleted1}>CGPA</Text>
          </Text>
        </Text>
        <View style={[styles.frameInner, styles.frameLayout]} />
        <Text
          style={[styles.creditsCompleted, styles.cgpaTypo]}
          numberOfLines={4}
        >
          <Text style={styles.helloAnirudhTContainer1}>
            <CreditValue />
            <Text style={styles.creditsCompleted1}>{`Credits 
Completed`}</Text>
          </Text>
        </Text>
        <View style={[styles.rectangleView, styles.frameLayout]} />
        <Text style={[styles.cgpa, styles.cgpaTypo]} numberOfLines={2}>
          <Text style={styles.helloAnirudhTContainer1}>
            <CurrentCGPA />
            <Text style={styles.creditsCompleted1}>CGPA</Text>
          </Text>
        </Text>
      </View>
      <Text style={styles.youreDoingGreat} numberOfLines={2}>
        You’re doing great, hang in there!
      </Text>
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa4, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={styles.dashboardChild1} />
      <Text style={[styles.home, styles.gpaFlexBox]} numberOfLines={1}>
        Home
      </Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]} numberOfLines={1}>
        GPA
      </Text>
      <Text style={[styles.cgpa4, styles.gpaFlexBox]}>CGPA</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]} numberOfLines={1}>
        Grades
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  dashboardLayout: {
    height: 2,
    width: 31,
    borderTopWidth: 2,
    borderColor: Color.colorGainsboro_100,
    borderStyle: "solid",
    left: 315,
    position: "absolute",
  },
  frameLayout: {
    width: 157,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_lgi,
    height: 151,
    top: 0,
    position: "absolute",
  },
  cgpaTypo: {
    color: Color.colorDarkseagreen,
    fontFamily: FontFamily.kumbhSansRegular,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    color: Color.colorLightgray,
    letterSpacing: 0.2,
    top: 766,
    justifyContent: "center",
    fontSize: FontSize.size_mini,
    fontFamily: FontFamily.kumbhSansRegular,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  dashboardChild: {
    top: 58,
  },
  dashboardItem: {
    top: 66,
  },
  dashboardInner: {
    top: 74,
  },
  marksparkVit: {
    top: 51,
    left: 92,
    fontSize: FontSize.size_xl,
    letterSpacing: 1.8,
    lineHeight: 24,
    fontFamily: FontFamily.comfortaaLight,
    color: Color.colorWhite,
    textAlign: "center",
    fontWeight: "300",
    position: "absolute",
  },
  frameIcon: {
    top: 59,
    left: 316,
    width: 29,
    height: 16,
    position: "absolute",
  },
  hello: {
    fontSize: FontSize.size_13xl,
    fontFamily: FontFamily.kumbhSansRegular,
  },
  anirudhT: {
    fontSize: FontSize.size_29xl,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
  },
  helloAnirudhTContainer1: {
    width: "100%",
  },
  helloAnirudhTContainer: {
    color: Color.colorGainsboro_100,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    top: 0,
    left: 0,
    height: 123,
    width: 289,
    position: "absolute",
  },
  frame: {
    top: 122,
    height: 123,
    width: 289,
    left: 14,
    position: "absolute",
    overflow: "hidden",
  },
  frameChild: {
    borderWidth: 1,
    borderColor: Color.colorBlack,
    width: 157,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_lgi,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 174,
  },
  text: {
    fontSize: FontSize.size_24xl,
  },
  creditsCompleted1: {
    fontSize: FontSize.size_mini,
  },
  creditsCompleted: {
    top: 10,
    width: 133,
    height: 130,
    left: 186,
  },
  frameItem: {
    borderWidth: 1,
    borderColor: Color.colorBlack,
    width: 157,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_lgi,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 0,
  },
  text1: {
    fontSize: FontSize.size_36xl,
  },
  cgpa: {
    top: 11,
    left: 11,
    width: 137,
    height: 132,
  },
  frameInner: {
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    width: 157,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_lgi,
    left: 174,
  },
  rectangleView: {
    borderWidth: 1,
    borderColor: Color.colorBlack,
    width: 157,
    backgroundColor: Color.colorDarkolivegreen_200,
    borderRadius: Border.br_lgi,
    borderStyle: "solid",
    left: 0,
  },
  frame1: {
    top: 292,
    height: 151,
    width: 331,
    left: 14,
    position: "absolute",
    overflow: "hidden",
  },
  youreDoingGreat: {
    top: 521,
    left: 15,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.kumbhSansLight,
    color: Color.colorDarkolivegreen_100,
    height: 99,
    justifyContent: "center",
    width: 331,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    fontWeight: "300",
    position: "absolute",
  },
  home: {
    left: 6,
  },
  grades: {
    left: 96,
  },
  gpa: {
    left: 186,
  },
  cgpa4: {
    left: 276,
  },
  vectorIcon: {
    width: "12.78%",
    right: "81.11%",
    left: "6.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon1: {
    height: "4.5%",
    width: "10.83%",
    top: "90.63%",
    right: "31.94%",
    left: "57.22%",
  },
  vectorIcon2: {
    width: "11.11%",
    right: "6.94%",
    left: "81.94%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    width: "13.61%",
    right: "55.56%",
    left: "30.83%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  dashboardChild1: {
    top: 710,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    left: 0,
    position: "absolute",
  },
  dashboard: {
    backgroundColor: Color.colorGray,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default Dashboard;
