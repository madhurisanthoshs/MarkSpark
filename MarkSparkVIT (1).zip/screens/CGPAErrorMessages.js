import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button as RNPButton } from "react-native-paper";
import { Button } from "@rneui/themed";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const CGPAErrorMessages = () => {
  return (
    <View style={styles.cgpaErrorMessages}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.cgpaErrorMessagesChild}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <Text style={styles.cgpaPredictor}>CGPA Predictor</Text>
      <View style={[styles.cgpaErrorMessagesItem, styles.cgpaShadowBox]} />
      <Text style={[styles.text, styles.textTypo1]}>170</Text>
      <View style={[styles.cgpaErrorMessagesInner, styles.cgpaShadowBox]} />
      <Text style={[styles.text1, styles.textTypo1]}>30</Text>
      <View style={[styles.rectangleView, styles.cgpaShadowBox]} />
      <View style={[styles.cgpaErrorMessagesChild1, styles.cgpaShadowBox]} />
      <View style={[styles.cgpaErrorMessagesChild2, styles.childPosition]} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={[styles.cgpaErrorMessagesChild2, styles.childPosition]} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={[styles.cgpaErrorMessagesChild2, styles.childPosition]} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={[styles.cgpaErrorMessagesChild2, styles.childPosition]} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.cgpaErrorMessagesChild6} />
      <View style={styles.submitButton}>
        <RNPButton
          style={[styles.submitButtonChild, styles.childPosition]}
          mode="contained"
          contentStyle={styles.frameButtonBtn}
        />
        <Text style={styles.submit}>Submit</Text>
      </View>
      <Text style={[styles.text2, styles.textTypo1]}>11.5</Text>
      <Image
        style={[styles.polygonIcon, styles.cgpaChildLayout]}
        contentFit="cover"
        source={require("../assets/polygon-3.png")}
      />
      <Text style={[styles.text3, styles.textTypo]}>!</Text>
      <Text style={[styles.valueNeedsTo, styles.valueTypo]}>
        Value needs to be between 0 and 10!
      </Text>
      <Text style={[styles.text4, styles.textTypo1]}>10.5</Text>
      <Image
        style={[styles.cgpaErrorMessagesChild7, styles.cgpaChildLayout]}
        contentFit="cover"
        source={require("../assets/polygon-3.png")}
      />
      <Text style={[styles.text5, styles.textTypo]}>!</Text>
      <Text style={[styles.valueNeedsTo1, styles.valueTypo]}>
        Value needs to be between 0 and 10!
      </Text>
      <Image
        style={[styles.cgpaErrorMessagesChild8, styles.cgpaChildLayout]}
        contentFit="cover"
        source={require("../assets/polygon-3.png")}
      />
      <Text style={[styles.text6, styles.textTypo]}>!</Text>
      <Text style={[styles.valueNeedsTo2, styles.valueTypo]}>
        Value needs to be between 0 and 28!
      </Text>
      <Image
        style={[styles.cgpaErrorMessagesChild9, styles.cgpaChildLayout]}
        contentFit="cover"
        source={require("../assets/polygon-3.png")}
      />
      <Text style={[styles.text7, styles.textTypo]}>!</Text>
      <Text style={[styles.valueNeedsTo3, styles.valueTypo]}>
        Value needs to be between 0 and 160!
      </Text>
      <Button
        radius="5"
        iconPosition="left"
        type="clear"
        containerStyle={styles.lineIconBtn}
        buttonStyle={styles.lineIconBtn1}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  frameButtonBtn: {
    height: 48,
    width: 113,
  },
  lineIconBtn: {
    left: 18,
    top: 24,
    position: "absolute",
  },
  lineIconBtn1: {
    borderStyle: "solid",
    width: 11,
    height: 18,
  },
  cgpaShadowBox: {
    height: 62,
    width: 330,
    backgroundColor: Color.colorDarkslategray_100,
    borderRadius: Border.br_12xl,
    left: 15,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  textTypo1: {
    height: 41,
    width: 298,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansLight,
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontWeight: "300",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  childPosition: {
    left: 0,
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    justifyContent: "center",
    fontFamily: FontFamily.kumbhSansRegular,
    fontSize: FontSize.size_mini,
    top: 766,
    color: Color.colorLightgray,
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout2: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconLayout: {
    flexDirection: "row",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  cgpaChildLayout: {
    height: 28,
    width: 32,
    left: 298,
    position: "absolute",
  },
  textTypo: {
    height: 19,
    width: 9,
    color: Color.colorGray,
    fontFamily: FontFamily.kumbhSansBlack,
    fontWeight: "900",
    fontSize: FontSize.size_4xl,
    justifyContent: "center",
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    left: 310,
    textAlign: "center",
    position: "absolute",
  },
  valueTypo: {
    height: 44,
    width: 205,
    fontSize: FontSize.size_lg,
    left: 74,
    color: Color.colorDarkseagreen,
    justifyContent: "center",
    fontFamily: FontFamily.kumbhSansRegular,
    letterSpacing: 0.2,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  marksparkVit: {
    top: 23,
    left: 80,
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    color: Color.colorWhite,
    fontWeight: "300",
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  cgpaErrorMessagesChild: {
    top: 25,
    width: 29,
    height: 16,
    left: 310,
    position: "absolute",
  },
  cgpaPredictor: {
    top: 88,
    left: 18,
    width: 204,
    height: 39,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  cgpaErrorMessagesItem: {
    top: 155,
  },
  text: {
    top: 166,
    left: 28,
    height: 41,
    width: 298,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansLight,
    letterSpacing: 0.2,
  },
  cgpaErrorMessagesInner: {
    top: 313,
  },
  text1: {
    top: 324,
    left: 32,
  },
  rectangleView: {
    top: 390,
  },
  cgpaErrorMessagesChild1: {
    top: 234,
  },
  cgpaErrorMessagesChild2: {
    top: 710,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
  },
  home: {
    left: 6,
  },
  grades: {
    left: 96,
  },
  gpa: {
    left: 186,
  },
  cgpa: {
    left: 276,
  },
  vectorIcon: {
    right: "81.11%",
    left: "6.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.94%",
    left: "57.22%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.94%",
    left: "81.94%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.56%",
    left: "30.83%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  cgpaErrorMessagesChild6: {
    top: 502,
    left: 37,
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorDarkolivegreen_200,
    width: 286,
    height: 60,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  submitButtonChild: {
    top: 0,
  },
  submit: {
    top: 8,
    fontSize: FontSize.size_5xl,
    width: 84,
    height: 33,
    color: Color.colorDarkseagreen,
    justifyContent: "center",
    letterSpacing: 0.2,
    left: 15,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
    position: "absolute",
  },
  submitButton: {
    top: 612,
    left: 124,
    width: 113,
    height: 48,
    position: "absolute",
  },
  text2: {
    top: 245,
    left: 28,
    height: 41,
    width: 298,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansLight,
    letterSpacing: 0.2,
  },
  polygonIcon: {
    top: 249,
  },
  text3: {
    top: 255,
  },
  valueNeedsTo: {
    top: 243,
  },
  text4: {
    top: 401,
    left: 28,
    height: 41,
    width: 298,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansLight,
    letterSpacing: 0.2,
  },
  cgpaErrorMessagesChild7: {
    top: 405,
  },
  text5: {
    top: 411,
  },
  valueNeedsTo1: {
    top: 399,
  },
  cgpaErrorMessagesChild8: {
    top: 328,
  },
  text6: {
    top: 334,
  },
  valueNeedsTo2: {
    top: 322,
  },
  cgpaErrorMessagesChild9: {
    top: 168,
  },
  text7: {
    top: 176,
  },
  valueNeedsTo3: {
    top: 164,
  },
  cgpaErrorMessages: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default CGPAErrorMessages;
