import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import CurrCGPA from "../components/CurrCGPA";
import CreditsEarned from "../components/CreditsEarned";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const GradeDistribution = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.gradeDistribution}>
      <Text style={[styles.cgpaDetails, styles.cgpaDetailsTypo]}>
        CGPA details
      </Text>
      <Text style={[styles.gradeDistribution1, styles.cgpaDetailsTypo]}>
        Grade distribution
      </Text>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.gradeDistributionChild}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <View style={[styles.gradeDistributionItem, styles.gradeLayout]} />
      <View style={[styles.gradeDistributionInner, styles.gradeLayout]} />
      <Text style={[styles.cgpa, styles.cgpaPosition]}>
        <Text style={styles.cgpaTxt}>
          <CurrCGPA />
          <Text style={styles.cgpa1Typo}>CGPA</Text>
        </Text>
      </Text>
      <Text style={[styles.gradedCreditsEarned, styles.cgpa1Typo]}>{`Graded
Credits Earned`}</Text>
      <View style={[styles.rectangleView, styles.cgpaPosition]} />
      <View style={styles.gradeDistributionChild1} />
      <View style={styles.gradeDistributionChild2} />
      <View style={styles.gradeDistributionChild3} />
      <CreditsEarned />
      <View style={styles.lineView} />
      <Image
        style={styles.lineIcon}
        contentFit="cover"
        source={require("../assets/line-14.png")}
      />
      <Image
        style={styles.gradeDistributionChild4}
        contentFit="cover"
        source={require("../assets/line-15.png")}
      />
      <Image
        style={styles.gradeDistributionChild5}
        contentFit="cover"
        source={require("../assets/line-16.png")}
      />
      <Image
        style={styles.gradeDistributionChild6}
        contentFit="cover"
        source={require("../assets/line-17.png")}
      />
      <Image
        style={styles.gradeDistributionChild7}
        contentFit="cover"
        source={require("../assets/line-18.png")}
      />
      <Image
        style={styles.gradeDistributionChild8}
        contentFit="cover"
        source={require("../assets/line-20.png")}
      />
      <Image
        style={styles.gradeDistributionChild9}
        contentFit="cover"
        source={require("../assets/line-21.png")}
      />
      <Image
        style={[styles.gradeDistributionChild10, styles.gradeChildLayout]}
        contentFit="cover"
        source={require("../assets/line-22.png")}
      />
      <Image
        style={[styles.gradeDistributionChild11, styles.gradeChildLayout]}
        contentFit="cover"
        source={require("../assets/line-23.png")}
      />
      <Text style={[styles.s34, styles.d1Typo]}>S (34%)</Text>
      <Text style={[styles.a32, styles.d1Typo]}>A (32%)</Text>
      <Text style={[styles.b31, styles.d1Typo]}>B (31%)</Text>
      <Text style={styles.c2}>C (2%)</Text>
      <Text style={[styles.d1, styles.d1Typo]}>D (1%)</Text>
      <View style={styles.gradeDistributionChild12} />
      <View style={styles.gradeDistributionChild13} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa2, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={styles.gradeDistributionChild13} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa2, styles.gpaFlexBox]}>CGPA</Text>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        color="#c3cfb7"
        onPress={() =>
          navigation.navigate("BottomTabsRoot", { screen: "GradeHistoryMenu" })
        }
        containerStyle={styles.lineIcon9Btn}
        buttonStyle={styles.lineIcon9Btn1}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  lineIcon9Btn: {
    left: 29,
    top: 34,
    position: "absolute",
  },
  lineIcon9Btn1: {
    borderStyle: "solid",
    width: 11,
    height: 18,
  },
  cgpaDetailsTypo: {
    height: 47,
    width: 217,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    fontSize: FontSize.size_lgi,
    left: 24,
    position: "absolute",
  },
  gradeLayout: {
    height: 99,
    borderRadius: Border.br_mini,
    top: 171,
    backgroundColor: Color.colorDarkolivegreen_200,
    position: "absolute",
  },
  cgpaPosition: {
    height: 88,
    top: 176,
    position: "absolute",
  },
  cgpa1Typo: {
    fontFamily: FontFamily.kumbhSansRegular,
    fontSize: FontSize.size_mini,
  },
  gradeChildLayout: {
    height: 32,
    position: "absolute",
  },
  d1Typo: {
    height: 30,
    color: Color.colorLightgray,
    fontSize: FontSize.size_smi,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    justifyContent: "center",
    letterSpacing: 0.2,
    top: 766,
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
    fontSize: FontSize.size_mini,
    textAlign: "center",
    alignItems: "center",
    display: "flex",
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorFlexBox: {
    flexDirection: "row",
    backgroundColor: Color.colorLightgray,
  },
  cgpaDetails: {
    top: 83,
  },
  gradeDistribution1: {
    top: 310,
  },
  marksparkVit: {
    top: 31,
    left: 94,
    fontSize: FontSize.size_xl,
    letterSpacing: 1.8,
    lineHeight: 24,
    fontWeight: "300",
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  gradeDistributionChild: {
    top: 35,
    left: 306,
    width: 29,
    height: 16,
    position: "absolute",
  },
  gradeDistributionItem: {
    left: 34,
    width: 99,
  },
  gradeDistributionInner: {
    left: 152,
    width: 173,
  },
  cgpaTxt: {
    width: "100%",
  },
  cgpa: {
    left: 42,
    width: 85,
    color: Color.colorDarkseagreen,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
  },
  gradedCreditsEarned: {
    top: 195,
    left: 163,
    width: 58,
    height: 49,
    color: Color.colorDarkseagreen,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    position: "absolute",
  },
  rectangleView: {
    left: 227,
    borderRadius: Border.br_27xl_5,
    backgroundColor: Color.colorDarkseagreen,
    width: 91,
  },
  gradeDistributionChild1: {
    top: 191,
    left: 243,
    borderRadius: Border.br_10xl_5,
    width: 59,
    height: 58,
    backgroundColor: Color.colorDarkolivegreen_200,
    position: "absolute",
  },
  gradeDistributionChild2: {
    left: 90,
    borderRadius: 90,
    width: 169,
    height: 164,
    top: 455,
    backgroundColor: Color.colorDarkolivegreen_200,
    position: "absolute",
  },
  gradeDistributionChild3: {
    top: 483,
    left: 120,
    borderRadius: 59,
    width: 109,
    height: 108,
    position: "absolute",
    backgroundColor: Color.colorGray,
  },
  lineView: {
    left: 174,
    borderStyle: "solid",
    borderColor: Color.colorDarkseagreen,
    borderRightWidth: 1,
    width: 1,
    height: 29,
    top: 455,
    position: "absolute",
  },
  lineIcon: {
    top: 581,
    left: 207,
    width: 17,
    height: 23,
    position: "absolute",
  },
  gradeDistributionChild4: {
    top: 556,
    width: 27,
    height: 13,
    left: 96,
    position: "absolute",
  },
  gradeDistributionChild5: {
    top: 463,
    width: 16,
    height: 25,
    left: 137,
    position: "absolute",
  },
  gradeDistributionChild6: {
    left: 161,
    width: 5,
    height: 28,
    top: 456,
    position: "absolute",
  },
  gradeDistributionChild7: {
    top: 480,
    left: 251,
    width: 43,
    height: 24,
    position: "absolute",
  },
  gradeDistributionChild8: {
    top: 616,
    left: 141,
    width: 9,
    height: 38,
    position: "absolute",
  },
  gradeDistributionChild9: {
    top: 490,
    left: 59,
    width: 38,
    height: 15,
    position: "absolute",
  },
  gradeDistributionChild10: {
    top: 427,
    width: 11,
    left: 137,
  },
  gradeDistributionChild11: {
    top: 424,
    left: 165,
    width: 3,
  },
  s34: {
    left: 291,
    width: 51,
    top: 456,
  },
  a32: {
    top: 650,
    left: 121,
    width: 50,
  },
  b31: {
    top: 467,
    left: 18,
    width: 51,
  },
  c2: {
    top: 405,
    width: 51,
    color: Color.colorLightgray,
    fontSize: FontSize.size_smi,
    left: 96,
    height: 29,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    position: "absolute",
  },
  d1: {
    top: 400,
    left: 153,
    width: 51,
  },
  gradeDistributionChild12: {
    top: 284,
    left: 345,
    borderRadius: Border.br_9xs_5,
    width: 7,
    height: 242,
    backgroundColor: Color.colorLightgray,
    position: "absolute",
  },
  gradeDistributionChild13: {
    top: 710,
    left: 0,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    position: "absolute",
  },
  home: {
    left: 6,
  },
  grades: {
    left: 96,
  },
  gpa: {
    left: 186,
  },
  cgpa2: {
    left: 276,
  },
  vectorIcon: {
    right: "81.11%",
    left: "6.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.94%",
    left: "57.22%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.94%",
    left: "81.94%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.56%",
    left: "30.83%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  gradeDistribution: {
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.colorGray,
  },
});

export default GradeDistribution;
