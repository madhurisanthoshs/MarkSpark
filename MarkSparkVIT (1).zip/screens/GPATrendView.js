import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import GraphGPA from "../components/GraphGPA";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const GPATrendView = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.gpaTrendView}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <View style={[styles.gpaTrendViewChild, styles.itemViewLayout]} />
      <View style={[styles.gpaTrendViewItem, styles.itemViewLayout]} />
      <View style={[styles.gpaTrendViewInner, styles.itemViewLayout]} />
      <Text style={styles.gpaTrendView1}>GPA trend view</Text>
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.frameIcon}
        contentFit="cover"
        source={require("../assets/frame-27.png")}
      />
      <View style={[styles.gpaTrendViewItem, styles.itemViewLayout]} />
      <View style={[styles.gpaTrendViewInner, styles.itemViewLayout]} />
      <Text style={styles.gpaTrendView1}>{` `}</Text>
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        color="#c3cfb7"
        onPress={() =>
          navigation.navigate("BottomTabsRoot", { screen: "GPAMenu" })
        }
        containerStyle={styles.lineIconBtn}
        buttonStyle={styles.lineIconBtn1}
      />
      <View style={[styles.gpaTrendViewChild5, styles.childLayout]} />
      <View style={styles.graph}>
        <GraphGPA />
        <Image
          style={styles.graphChild}
          contentFit="cover"
          source={require("../assets/line-49.png")}
        />
        <Image
          style={[styles.graphItem, styles.itemViewLayout]}
          contentFit="cover"
          source={require("../assets/line-50.png")}
        />
        <Image
          style={[styles.graphInner, styles.graphPosition]}
          contentFit="cover"
          source={require("../assets/line-52.png")}
        />
        <Image
          style={[styles.ellipseIcon, styles.graphChildLayout1]}
          contentFit="cover"
          source={require("../assets/ellipse-9.png")}
        />
        <Image
          style={[styles.graphChild1, styles.graphChildLayout1]}
          contentFit="cover"
          source={require("../assets/ellipse-9.png")}
        />
        <Image
          style={styles.lineIcon}
          contentFit="cover"
          source={require("../assets/line-53.png")}
        />
        <Image
          style={[styles.graphChild2, styles.graphChildPosition3]}
          contentFit="cover"
          source={require("../assets/line-54.png")}
        />
        <Image
          style={[styles.graphChild3, styles.graphChildPosition2]}
          contentFit="cover"
          source={require("../assets/line-55.png")}
        />
        <Image
          style={[styles.graphChild4, styles.graphChildPosition1]}
          contentFit="cover"
          source={require("../assets/line-56.png")}
        />
        <Text style={[styles.text1, styles.textTypo]}>8.82</Text>
        <Text style={[styles.text2, styles.textTypo]}>8</Text>
        <Text style={[styles.sem1, styles.semTypo]}>sem-1</Text>
        <Text style={[styles.sem2, styles.semTypo]}>sem-2</Text>
        <Text style={[styles.sem3, styles.semTypo]}>sem-3</Text>
        <Text style={[styles.sem4, styles.semTypo]}>sem-4</Text>
        <Text style={[styles.sem5, styles.semTypo]}>sem-5</Text>
        <Text style={[styles.sem6, styles.semTypo]}>sem-6</Text>
        <Text style={styles.text3}>8.75</Text>
        <View style={[styles.graphChild5, styles.graphChildLayout]} />
        <View style={[styles.graphChild6, styles.graphChildLayout]} />
        <View style={[styles.graphChild7, styles.graphChildBorder]} />
        <Image
          style={[styles.graphChild8, styles.graphChildPosition1]}
          contentFit="cover"
          source={require("../assets/line-60.png")}
        />
        <View style={[styles.graphChild9, styles.graphPosition]} />
        <View style={[styles.graphChild10, styles.graphChildBorder]} />
        <View style={[styles.graphChild11, styles.graphChildPosition3]} />
        <View style={[styles.graphChild12, styles.graphChildPosition2]} />
        <View style={[styles.graphChild13, styles.graphChildBorder1]} />
        <Image
          style={[styles.graphChild14, styles.graphChildLayout1]}
          contentFit="cover"
          source={require("../assets/ellipse-9.png")}
        />
        <Image
          style={[styles.graphChild15, styles.graphChildLayout1]}
          contentFit="cover"
          source={require("../assets/ellipse-9.png")}
        />
        <Image
          style={[styles.graphChild16, styles.graphChildLayout1]}
          contentFit="cover"
          source={require("../assets/ellipse-9.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  lineIconBtn: {
    left: 18,
    top: 24,
    position: "absolute",
  },
  lineIconBtn1: {
    borderStyle: "solid",
    width: 11,
    height: 18,
  },
  itemViewLayout: {
    height: 2,
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    justifyContent: "center",
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
    letterSpacing: 0.2,
    fontSize: FontSize.size_mini,
    top: 766,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout2: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconLayout: {
    flexDirection: "row",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  childLayout: {
    height: 119,
    width: 1,
    borderRightWidth: 1,
    borderRadius: 0.001,
    borderColor: Color.colorGray,
    borderStyle: "dashed",
  },
  graphPosition: {
    left: 108,
    position: "absolute",
  },
  graphChildLayout1: {
    height: 8,
    width: 8,
    position: "absolute",
  },
  graphChildPosition3: {
    top: 143,
    position: "absolute",
  },
  graphChildPosition2: {
    left: 224,
    position: "absolute",
  },
  graphChildPosition1: {
    top: 123,
    position: "absolute",
  },
  textTypo: {
    height: 17,
    color: Color.colorDarkslategray_100,
    fontSize: FontSize.size_5xs,
    left: 5,
    width: 29,
    justifyContent: "center",
    fontFamily: FontFamily.kumbhSansRegular,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  semTypo: {
    top: 280,
    height: 17,
    color: Color.colorDarkslategray_100,
    fontSize: FontSize.size_5xs,
    width: 29,
    justifyContent: "center",
    fontFamily: FontFamily.kumbhSansRegular,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  graphChildLayout: {
    height: 1,
    borderTopWidth: 1,
  },
  graphChildBorder: {
    top: 156,
    borderRadius: 0.001,
    borderColor: Color.colorGray,
    borderStyle: "dashed",
    position: "absolute",
  },
  graphChildBorder1: {
    borderRightWidth: 1,
    width: 1,
    borderRadius: 0.001,
    borderColor: Color.colorGray,
    borderStyle: "dashed",
  },
  marksparkVit: {
    top: 23,
    left: 80,
    fontWeight: "300",
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  gpaTrendViewChild: {
    top: 24,
    width: 31,
    borderTopWidth: 2,
    borderColor: Color.colorGainsboro_100,
    borderStyle: "solid",
    left: 309,
    height: 2,
  },
  gpaTrendViewItem: {
    top: 32,
    width: 31,
    borderTopWidth: 2,
    borderColor: Color.colorGainsboro_100,
    borderStyle: "solid",
    left: 309,
    height: 2,
  },
  gpaTrendViewInner: {
    top: 40,
    width: 31,
    borderTopWidth: 2,
    borderColor: Color.colorGainsboro_100,
    borderStyle: "solid",
    left: 309,
    height: 2,
  },
  gpaTrendView1: {
    top: 71,
    left: 15,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
    textAlign: "left",
    width: 204,
    height: 39,
    alignItems: "center",
    display: "flex",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  rectangleView: {
    top: 710,
    left: 1,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    position: "absolute",
  },
  home: {
    left: 7,
  },
  grades: {
    left: 97,
  },
  gpa: {
    left: 187,
  },
  cgpa: {
    left: 277,
  },
  vectorIcon: {
    right: "80.83%",
    left: "6.39%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.67%",
    left: "57.5%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.67%",
    left: "82.22%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.28%",
    left: "31.11%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  frameIcon: {
    top: 25,
    left: 310,
    width: 29,
    maxHeight: "100%",
    position: "absolute",
  },
  gpaTrendViewChild5: {
    top: 400,
    left: 242,
    position: "absolute",
  },
  graphChild: {
    top: 41,
    left: 36,
    height: 239,
    width: 1,
    position: "absolute",
  },
  graphItem: {
    top: 278,
    left: 35,
    width: 260,
  },
  graphInner: {
    top: 130,
    width: 41,
    height: 26,
  },
  ellipseIcon: {
    left: 249,
    top: 133,
  },
  graphChild1: {
    top: 139,
    left: 181,
  },
  lineIcon: {
    width: 39,
    height: 13,
    left: 149,
    top: 143,
    position: "absolute",
  },
  graphChild2: {
    left: 184,
    height: 18,
    width: 40,
  },
  graphChild3: {
    height: 25,
    top: 137,
    width: 31,
  },
  graphChild4: {
    left: 70,
    height: 7,
    width: 40,
  },
  text1: {
    top: 116,
  },
  text2: {
    top: 147,
  },
  sem1: {
    left: 55,
  },
  sem2: {
    left: 94,
  },
  sem3: {
    left: 135,
  },
  sem4: {
    left: 174,
  },
  sem5: {
    left: 210,
  },
  sem6: {
    left: 241,
  },
  text3: {
    color: Color.colorDarkslategray_100,
    fontSize: FontSize.size_5xs,
    left: 5,
    height: 13,
    top: 133,
    width: 29,
    justifyContent: "center",
    fontFamily: FontFamily.kumbhSansRegular,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  graphChild5: {
    left: 38,
    height: 1,
    borderTopWidth: 1,
    top: 123,
    position: "absolute",
    borderRadius: 0.001,
    borderColor: Color.colorGray,
    borderStyle: "dashed",
    width: 31,
  },
  graphChild6: {
    left: 40,
    width: 212,
    top: 137,
    borderRadius: 0.001,
    borderColor: Color.colorGray,
    borderStyle: "dashed",
    position: "absolute",
  },
  graphChild7: {
    width: 112,
    height: 1,
    borderTopWidth: 1,
    left: 38,
  },
  graphChild8: {
    left: 68,
    height: 155,
    width: 1,
  },
  graphChild9: {
    height: 145,
    top: 133,
    width: 1,
    borderRightWidth: 1,
    borderRadius: 0.001,
    borderColor: Color.colorGray,
    borderStyle: "dashed",
  },
  graphChild10: {
    height: 125,
    left: 149,
    top: 156,
    width: 1,
    borderRightWidth: 1,
  },
  graphChild11: {
    left: 188,
    height: 135,
    width: 1,
    borderRightWidth: 1,
    borderRadius: 0.001,
    borderColor: Color.colorGray,
    borderStyle: "dashed",
  },
  graphChild12: {
    top: 161,
    height: 119,
    width: 1,
    borderRightWidth: 1,
    borderRadius: 0.001,
    borderColor: Color.colorGray,
    borderStyle: "dashed",
  },
  graphChild13: {
    left: 255,
    height: 143,
    top: 137,
    width: 1,
    position: "absolute",
  },
  graphChild14: {
    top: 126,
    left: 104,
  },
  graphChild15: {
    top: 119,
    left: 65,
  },
  graphChild16: {
    top: 152,
    left: 145,
  },
  graph: {
    top: 239,
    left: 18,
    width: 321,
    height: 321,
    position: "absolute",
  },
  gpaTrendView: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default GPATrendView;
