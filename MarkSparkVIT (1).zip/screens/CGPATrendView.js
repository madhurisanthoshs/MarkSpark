import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Button } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import Graph from "../components/Graph";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const CGPATrendView = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.cgpaTrendView}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <View style={[styles.cgpaTrendViewChild, styles.cgpaViewLayout]} />
      <View style={[styles.cgpaTrendViewItem, styles.cgpaViewLayout]} />
      <View style={[styles.cgpaTrendViewInner, styles.cgpaViewLayout]} />
      <Text style={styles.cgpaTrendView1}>CGPA trend view</Text>
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector2.png")}
      />
      <Image
        style={[styles.vectorIcon3, styles.vectorIconLayout2]}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
      <Image
        style={styles.frameIcon}
        contentFit="cover"
        source={require("../assets/frame-28.png")}
      />
      <Text style={styles.cgpaTrendView1}>{` `}</Text>
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <View style={styles.rectangleView} />
      <Text style={[styles.home, styles.gpaFlexBox]}>Home</Text>
      <Text style={[styles.grades, styles.gpaFlexBox]}>Grades</Text>
      <Text style={[styles.gpa, styles.gpaFlexBox]}>GPA</Text>
      <Text style={[styles.cgpa, styles.gpaFlexBox]}>CGPA</Text>
      <Button
        radius={5}
        iconPosition="left"
        type="solid"
        onPress={() =>
          navigation.navigate("BottomTabsRoot", { screen: "CGPAMenu" })
        }
        containerStyle={styles.lineIconBtn}
        buttonStyle={styles.lineIconBtn1}
      />
      <View style={styles.lineView} />
      <Graph />
    </View>
  );
};

const styles = StyleSheet.create({
  lineIconBtn: {
    left: 18,
    top: 24,
    position: "absolute",
  },
  lineIconBtn1: {
    borderStyle: "solid",
    width: 11,
    height: 18,
    backgroundColor: "#C3CFB7",
  },
  cgpaViewLayout: {
    height: 2,
    width: 31,
    borderTopWidth: 2,
    borderColor: Color.colorGainsboro_100,
    borderStyle: "solid",
    left: 309,
    position: "absolute",
  },
  gpaFlexBox: {
    height: 34,
    width: 78,
    justifyContent: "center",
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansRegular,
    letterSpacing: 0.2,
    fontSize: FontSize.size_mini,
    top: 766,
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    position: "absolute",
  },
  vectorIconLayout2: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconLayout: {
    flexDirection: "row",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  marksparkVit: {
    top: 23,
    left: 80,
    fontWeight: "300",
    fontFamily: FontFamily.comfortaaLight,
    textAlign: "center",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  cgpaTrendViewChild: {
    top: 24,
  },
  cgpaTrendViewItem: {
    top: 32,
  },
  cgpaTrendViewInner: {
    top: 40,
  },
  cgpaTrendView1: {
    top: 71,
    left: 15,
    fontWeight: "500",
    fontFamily: FontFamily.kumbhSansMedium,
    textAlign: "left",
    width: 204,
    height: 39,
    alignItems: "center",
    display: "flex",
    color: Color.colorWhite,
    lineHeight: 24,
    letterSpacing: 1.8,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  rectangleView: {
    top: 710,
    left: 1,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    height: 90,
    position: "absolute",
  },
  home: {
    left: 7,
  },
  grades: {
    left: 97,
  },
  gpa: {
    left: 187,
  },
  cgpa: {
    left: 277,
  },
  vectorIcon: {
    right: "80.83%",
    left: "6.39%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
    width: "12.78%",
  },
  vectorIcon1: {
    height: "4.5%",
    top: "90.63%",
    right: "31.67%",
    left: "57.5%",
    width: "10.83%",
  },
  vectorIcon2: {
    right: "6.67%",
    left: "82.22%",
    width: "11.11%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  vectorIcon3: {
    right: "55.28%",
    left: "31.11%",
    width: "13.61%",
    top: "90.13%",
    height: "5%",
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "4.88%",
  },
  frameIcon: {
    top: 25,
    left: 310,
    width: 29,
    height: 16,
    position: "absolute",
  },
  lineView: {
    top: 400,
    left: 242,
    borderStyle: "dashed",
    borderColor: Color.colorGray,
    borderRadius: 0.001,
    borderRightWidth: 1,
    width: 1,
    height: 119,
    position: "absolute",
  },
  cgpaTrendView: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default CGPATrendView;
