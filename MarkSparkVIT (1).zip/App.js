const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import LoginMainScreen from "./screens/LoginMainScreen";
import LoginSigningIn from "./screens/LoginSigningIn";
import LoginCaptcha from "./screens/LoginCaptcha";
import LoginErrorMessages from "./components/LoginErrorMessages";
import DashboardOpenBurgerMenu from "./screens/DashboardOpenBurgerMenu";
import Dashboard from "./screens/Dashboard";
import GradeDistribution from "./screens/GradeDistribution";
import CurriculumDistribution from "./screens/CurriculumDistribution";
import EffectiveGradeHistory from "./screens/EffectiveGradeHistory";
import GradeHistoryMenu from "./screens/GradeHistoryMenu";
import GPACalculatedGPA from "./screens/GPACalculatedGPA";
import GPATrendView from "./screens/GPATrendView";
import GPATrendViewLoadingScreen from "./screens/GPATrendViewLoadingScreen";
import GPALoadingScreen from "./screens/GPALoadingScreen";
import GPAEnteringCredits from "./screens/GPAEnteringCredits";
import GPAEnteringGrades from "./screens/GPAEnteringGrades";
import GPAMainScreen from "./screens/GPAMainScreen";
import GPAMenu from "./screens/GPAMenu";
import CGPATrendView from "./screens/CGPATrendView";
import CGPATrendViewLoadingScreen from "./screens/CGPATrendViewLoadingScreen";
import CGPACalculatedCGPA from "./screens/CGPACalculatedCGPA";
import CGPALoadingScreen from "./screens/CGPALoadingScreen";
import CGPAErrorMessages from "./screens/CGPAErrorMessages";
import CGPAMainScreen from "./screens/CGPAMainScreen";
import CGPAMenu from "./screens/CGPAMenu";
import VectorIcon47 from "./components/VectorIcon4";
import VectorIcon51 from "./components/VectorIcon5";
import VectorIcon61 from "./components/VectorIcon6";
import VectorIcon71 from "./components/VectorIcon7";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

const Tab = createBottomTabNavigator();
function BottomTabsRoot({ navigation }) {
  const [bottomTabItemsNormal] = React.useState([
    <VectorIcon47 />,
    <VectorIcon71 />,
    <VectorIcon51 />,
    <VectorIcon61 />,
  ]);
  const [bottomTabItemsActive] = React.useState([
    <VectorIcon47 />,
    <VectorIcon71 />,
    <VectorIcon51 />,
    <VectorIcon61 />,
  ]);
  return (
    <Tab.Navigator
      screenOptions={{ headerShown: false }}
      tabBar={({ state, descriptors, navigation }) => {
        const activeIndex = state.index;
        return (
          <View
            style={{
              height: 40,
              width: "13.61%",
              backgroundColor: "#c3cfb7",
              flexDirection: "row",
            }}
          >
            {bottomTabItemsNormal.map((item, index) => {
              const isFocused = state.index === index;
              return (
                <Pressable
                  key={index}
                  onPress={() => {
                    navigation.navigate({
                      name: state.routes[index].name,
                      merge: true,
                    });
                  }}
                >
                  {activeIndex === index
                    ? bottomTabItemsActive[index] || item
                    : item}
                </Pressable>
              );
            })}
          </View>
        );
      }}
    >
      <Tab.Screen
        name="Dashboard"
        component={Dashboard}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="GradeHistoryMenu"
        component={GradeHistoryMenu}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="GPAMenu"
        component={GPAMenu}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="CGPAMenu"
        component={CGPAMenu}
        options={{ headerShown: false }}
      />
    </Tab.Navigator>
  );
}

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "Comfortaa-Light": require("./assets/fonts/Comfortaa-Light.ttf"),
    "Comfortaa-Regular": require("./assets/fonts/Comfortaa-Regular.ttf"),
    "KumbhSans-Light": require("./assets/fonts/KumbhSans-Light.ttf"),
    "KumbhSans-Regular": require("./assets/fonts/KumbhSans-Regular.ttf"),
    "KumbhSans-Medium": require("./assets/fonts/KumbhSans-Medium.ttf"),
    "KumbhSans-Bold": require("./assets/fonts/KumbhSans-Bold.ttf"),
    "KumbhSans-Black": require("./assets/fonts/KumbhSans-Black.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator
            initialRouteName="LoginMainScreen"
            screenOptions={{ headerShown: false }}
          >
            <Stack.Screen name="BottomTabsRoot" component={BottomTabsRoot} />
            <Stack.Screen
              name="LoginMainScreen"
              component={LoginMainScreen}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LoginSigningIn"
              component={LoginSigningIn}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LoginCaptcha"
              component={LoginCaptcha}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LoginErrorMessages"
              component={LoginErrorMessages}
              options={(props) => ({
                headerShown: true,

                headerTitle: "MarkSpark VIT",
              })}
            />
            <Stack.Screen
              name="DashboardOpenBurgerMenu"
              component={DashboardOpenBurgerMenu}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GradeDistribution"
              component={GradeDistribution}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CurriculumDistribution"
              component={CurriculumDistribution}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="EffectiveGradeHistory"
              component={EffectiveGradeHistory}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GPACalculatedGPA"
              component={GPACalculatedGPA}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GPATrendView"
              component={GPATrendView}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GPATrendViewLoadingScreen"
              component={GPATrendViewLoadingScreen}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GPALoadingScreen"
              component={GPALoadingScreen}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GPAEnteringCredits"
              component={GPAEnteringCredits}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GPAEnteringGrades"
              component={GPAEnteringGrades}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="GPAMainScreen"
              component={GPAMainScreen}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CGPATrendView"
              component={CGPATrendView}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CGPATrendViewLoadingScreen"
              component={CGPATrendViewLoadingScreen}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CGPACalculatedCGPA"
              component={CGPACalculatedCGPA}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CGPALoadingScreen"
              component={CGPALoadingScreen}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CGPAErrorMessages"
              component={CGPAErrorMessages}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CGPAMainScreen"
              component={CGPAMainScreen}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
