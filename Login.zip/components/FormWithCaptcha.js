import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Button, TextInput } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const FormWithCaptcha = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.captchaBox, styles.captchaLayout]}>
      <View style={[styles.captchaBoxChild, styles.captchaLayout]} />
      <Text style={[styles.captcha, styles.captchaFlexBox]} numberOfLines={1}>
        Captcha
      </Text>
      <Image
        style={[styles.captchaImageIcon, styles.placeholderPosition]}
        contentFit="contain"
        source={require("../assets/captcha-image.png")}
      />
      <Text
        style={[styles.solveTheCaptcha, styles.captchaFlexBox]}
        numberOfLines={1}
      >
        Solve the captcha:
      </Text>
      <Button
        style={[styles.submitButton, styles.buttonFlexBox]}
        mode="contained"
        labelStyle={styles.submitButtonBtn}
        onPress={() => navigation.navigate("LoginSigningIn")}
        contentStyle={styles.submitButtonBtn1}
      >
        Submit
      </Button>
      <Button
        style={[styles.cancelButton, styles.buttonFlexBox]}
        mode="outlined"
        labelStyle={styles.cancelButtonBtn}
        onPress={() => navigation.navigate("Login")}
        contentStyle={styles.cancelButtonBtn1}
      >
        Cancel
      </Button>
      <TextInput
        style={[styles.placeholder, styles.placeholderPosition]}
        label="Captcha"
        placeholder="Solve the captcha"
        mode="flat"
        placeholderTextColor="#fff"
        theme={{ colors: { text: "#fff", background: "#35402f" } }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  submitButtonBtn: {
    color: "#b4d99a",
    fontSize: 24,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  submitButtonBtn1: {
    borderRadius: 31,
    height: 48,
    width: 113,
  },
  cancelButtonBtn: {
    color: "#b4d99a",
    fontSize: 24,
    fontWeight: "500",
    fontFamily: "KumbhSans-Medium",
  },
  cancelButtonBtn1: {
    borderRadius: 31,
    height: 48,
    width: 113,
  },
  captchaLayout: {
    height: 315,
    width: 294,
    borderRadius: Border.br_20xl,
    position: "absolute",
  },
  captchaFlexBox: {
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  placeholderPosition: {
    width: 267,
    left: 12,
    position: "absolute",
  },
  buttonFlexBox: {
    justifyContent: "flex-end",
    top: 257,
    alignItems: "center",
    position: "absolute",
  },
  captchaBoxChild: {
    top: 0,
    left: 0,
    backgroundColor: Color.colorGray,
  },
  captcha: {
    top: 16,
    fontSize: FontSize.size_13xl,
    letterSpacing: 0.3,
    fontFamily: FontFamily.kumbhSansRegular,
    width: 171,
    left: 12,
  },
  captchaImageIcon: {
    top: 75,
    height: 57,
  },
  solveTheCaptcha: {
    top: 144,
    left: 14,
    fontSize: FontSize.size_xl,
    letterSpacing: 0.2,
    fontWeight: "300",
    fontFamily: FontFamily.kumbhSansLight,
    width: 265,
    height: 32,
  },
  submitButton: {
    left: 166,
  },
  cancelButton: {
    left: 12,
  },
  placeholder: {
    top: 182,
    borderRadius: Border.br_smi,
    backgroundColor: Color.colorDarkslategray_100,
    height: 56,
  },
  captchaBox: {
    top: 205,
    left: 33,
  },
});

export default FormWithCaptcha;
