import * as React from "react";
import { View, StyleProp, ViewStyle, Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const Frame = ({ style }) => {
  return (
    <View style={[styles.frame, style]}>
      <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  marksparkVit: {
    fontSize: FontSize.size_xl,
    letterSpacing: 1.8,
    lineHeight: 24,
    fontWeight: "300",
    fontFamily: FontFamily.comfortaaLight,
    color: Color.colorWhite,
    textAlign: "center",
  },
  frame: {
    width: 176,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Frame;
