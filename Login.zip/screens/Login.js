import * as React from "react";
import { TextInput } from "react-native-paper";
import { StyleSheet } from "react-native";
import { Color } from "../GlobalStyles";

const Login = () => {
  return (
    <TextInput
      style={styles.login}
      label="LoginUsing your VTOP credentials"
      placeholder="MarkSpark VIT"
      mode="flat"
      placeholderTextColor="#c3cfb7"
      theme={{
        fonts: { regular: { fontFamily: "Kumbh Sans", fontWeight: "Light" } },
        colors: { text: "#c3cfb7", background: "#000" },
      }}
    />
  );
};

const styles = StyleSheet.create({
  login: {
    backgroundColor: Color.colorBlack,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 14,
    paddingVertical: 40,
  },
});

export default Login;
