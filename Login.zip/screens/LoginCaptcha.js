import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import FrameContainer from "../components/FrameContainer";
import FormWithCaptcha from "../components/FormWithCaptcha";
import { FontFamily, Color, FontSize, Border, Padding } from "../GlobalStyles";

const LoginCaptcha = () => {
  return (
    <View style={styles.loginCaptcha}>
      <View style={styles.previousScreen}>
        <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
        <Text style={[styles.loginUsingYourContainer, styles.textFlexBox]}>
          <Text style={[styles.login, styles.loginTypo]}>{`Login
`}</Text>
          <Text style={[styles.usingYourVtop, styles.textTypo]}>
            Using your VTOP credentials
          </Text>
        </Text>
        <FrameContainer />
        <View style={styles.frame}>
          <Text style={[styles.text, styles.textLayout]}>*********</Text>
          <Image
            style={styles.frameChild}
            contentFit="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Image
            style={[styles.frameItem, styles.framePosition]}
            contentFit="cover"
            source={require("../assets/line-1.png")}
          />
          <Image
            style={[styles.frameInner, styles.framePosition]}
            contentFit="cover"
            source={require("../assets/line-2.png")}
          />
        </View>
        <View style={styles.frame1}>
          <Text style={[styles.signIn, styles.textLayout]}>Sign in</Text>
        </View>
      </View>
      <View style={styles.overlay} />
      <FormWithCaptcha />
    </View>
  );
};

const styles = StyleSheet.create({
  textFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  loginTypo: {
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
  },
  textTypo: {
    fontFamily: FontFamily.kumbhSansLight,
    fontWeight: "300",
  },
  textLayout: {
    height: 41,
    display: "flex",
    letterSpacing: 0.2,
    alignItems: "center",
  },
  framePosition: {
    height: 34,
    top: 14,
    position: "absolute",
  },
  marksparkVit: {
    left: 78,
    letterSpacing: 1.8,
    lineHeight: 24,
    fontFamily: FontFamily.comfortaaLight,
    color: Color.colorWhite,
    textAlign: "center",
    fontWeight: "300",
    fontSize: FontSize.size_xl,
    top: 0,
    position: "absolute",
  },
  login: {
    fontSize: FontSize.size_21xl,
  },
  usingYourVtop: {
    fontSize: FontSize.size_base,
  },
  loginUsingYourContainer: {
    top: 103,
    left: 11,
    color: Color.colorGainsboro,
    width: 249,
    height: 78,
  },
  text: {
    top: 10,
    left: 71,
    color: Color.colorLightgray,
    width: 258,
    fontFamily: FontFamily.kumbhSansLight,
    fontWeight: "300",
    textAlign: "left",
    position: "absolute",
    fontSize: FontSize.size_xl,
    height: 41,
    display: "flex",
    letterSpacing: 0.2,
  },
  frameChild: {
    top: 8,
    left: 10,
    width: 48,
    height: 45,
    position: "absolute",
  },
  frameItem: {
    left: 18,
    width: 30,
  },
  frameInner: {
    left: 19,
    width: 31,
  },
  frame: {
    top: 341,
    left: 1,
    backgroundColor: Color.colorDarkslategray_100,
    width: 330,
    height: 62,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_12xl,
    position: "absolute",
    overflow: "hidden",
  },
  signIn: {
    fontSize: FontSize.size_5xl,
    color: Color.colorDarkseagreen,
    justifyContent: "center",
    width: 102,
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
    textAlign: "center",
  },
  frame1: {
    top: 514,
    left: 75,
    backgroundColor: Color.colorDarkolivegreen,
    width: 181,
    paddingHorizontal: 0,
    paddingVertical: Padding.p_3xs,
    alignItems: "center",
    height: 62,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_12xl,
    position: "absolute",
    overflow: "hidden",
  },
  previousScreen: {
    top: 40,
    left: 15,
    width: 331,
    height: 576,
    position: "absolute",
  },
  overlay: {
    left: 0,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    top: 0,
    position: "absolute",
    height: 800,
  },
  loginCaptcha: {
    backgroundColor: Color.colorBlack,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default LoginCaptcha;
