import React, { useState } from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { ActivityIndicator } from "react-native-paper";
import FrameContainer from "../components/FrameContainer";
import { FontFamily, Color, Border, FontSize, Padding } from "../GlobalStyles";

const LoginSigningIn = () => {
  const [
    loadingIconActivityIndicatorAnimating,
    setLoadingIconActivityIndicatorAnimating,
  ] = useState(true);

  return (
    <View style={styles.loginSigningIn}>
      <View style={styles.previousScreen}>
        <Text style={styles.marksparkVit}>MarkSpark VIT</Text>
        <Text style={styles.loginUsingYourContainer}>
          <Text style={[styles.login, styles.loginTypo]}>{`Login
`}</Text>
          <Text style={[styles.usingYourVtop, styles.textTypo]}>
            Using your VTOP credentials
          </Text>
        </Text>
        <FrameContainer />
        <View style={[styles.frame, styles.frameShadowBox]}>
          <Text style={[styles.text, styles.textLayout]}>*********</Text>
          <Image
            style={styles.frameChild}
            contentFit="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Image
            style={[styles.frameItem, styles.framePosition]}
            contentFit="cover"
            source={require("../assets/line-1.png")}
          />
          <Image
            style={[styles.frameInner, styles.framePosition]}
            contentFit="cover"
            source={require("../assets/line-2.png")}
          />
        </View>
        <View style={[styles.frame1, styles.textFlexBox]}>
          <Text style={[styles.signIn, styles.signFlexBox]}>Sign in</Text>
        </View>
      </View>
      <View style={styles.overlay} />
      <View style={[styles.signInMessage, styles.signFlexBox]}>
        <ActivityIndicator
          style={styles.loadingIcon}
          animating={loadingIconActivityIndicatorAnimating}
          size="[object Object]"
          color="#939393"
        />
        <Text
          style={[styles.signInMessage1, styles.signTypo]}
          numberOfLines={1}
        >
          Signing you in...
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  loginTypo: {
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
  },
  textTypo: {
    fontFamily: FontFamily.kumbhSansLight,
    fontWeight: "300",
  },
  frameShadowBox: {
    height: 62,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_12xl,
    overflow: "hidden",
  },
  textLayout: {
    height: 41,
    display: "flex",
    letterSpacing: 0.2,
  },
  framePosition: {
    height: 34,
    top: 14,
    position: "absolute",
  },
  textFlexBox: {
    alignItems: "center",
    position: "absolute",
  },
  signFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  signTypo: {
    fontSize: FontSize.size_5xl,
    textAlign: "center",
  },
  marksparkVit: {
    left: 78,
    letterSpacing: 1.8,
    lineHeight: 24,
    fontFamily: FontFamily.comfortaaLight,
    color: Color.colorWhite,
    textAlign: "center",
    fontWeight: "300",
    fontSize: FontSize.size_xl,
    top: 0,
    position: "absolute",
  },
  login: {
    fontSize: FontSize.size_21xl,
  },
  usingYourVtop: {
    fontSize: FontSize.size_base,
  },
  loginUsingYourContainer: {
    top: 103,
    left: 11,
    color: Color.colorGainsboro,
    width: 249,
    height: 78,
    textAlign: "left",
    position: "absolute",
  },
  text: {
    top: 10,
    left: 71,
    width: 258,
    alignItems: "center",
    position: "absolute",
    color: Color.colorLightgray,
    fontFamily: FontFamily.kumbhSansLight,
    fontWeight: "300",
    textAlign: "left",
    fontSize: FontSize.size_xl,
    height: 41,
    display: "flex",
    letterSpacing: 0.2,
  },
  frameChild: {
    top: 8,
    left: 10,
    width: 48,
    height: 45,
    position: "absolute",
  },
  frameItem: {
    left: 18,
    width: 30,
  },
  frameInner: {
    left: 19,
    width: 31,
  },
  frame: {
    top: 341,
    left: 1,
    backgroundColor: Color.colorDarkslategray_100,
    width: 330,
    position: "absolute",
  },
  signIn: {
    color: Color.colorDarkseagreen,
    width: 102,
    fontSize: FontSize.size_5xl,
    textAlign: "center",
    height: 41,
    display: "flex",
    letterSpacing: 0.2,
    fontFamily: FontFamily.kumbhSansMedium,
    fontWeight: "500",
  },
  frame1: {
    top: 514,
    left: 75,
    backgroundColor: Color.colorDarkolivegreen,
    width: 181,
    paddingHorizontal: 0,
    paddingVertical: Padding.p_3xs,
    height: 62,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_12xl,
    overflow: "hidden",
  },
  previousScreen: {
    top: 40,
    left: 15,
    width: 331,
    height: 576,
    position: "absolute",
  },
  overlay: {
    left: 0,
    backgroundColor: Color.colorDarkslategray_200,
    width: 360,
    top: 0,
    position: "absolute",
    height: 800,
  },
  loadingIcon: {
    width: 69,
    height: 65,
    alignSelf: "center",
  },
  signInMessage1: {
    fontFamily: FontFamily.kumbhSansRegular,
    height: 61,
    marginTop: 33,
    width: 195,
    color: Color.colorLightgray,
  },
  signInMessage: {
    top: 321,
    left: 83,
    height: 159,
    width: 195,
    position: "absolute",
  },
  loginSigningIn: {
    backgroundColor: Color.colorBlack,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default LoginSigningIn;
