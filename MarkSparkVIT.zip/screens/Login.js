import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { TextInput } from "react-native-paper";
import { Color } from "../GlobalStyles";

const Login = () => {
  return (
    <View style={[styles.login, styles.loginFlexBox]}>
      <TextInput
        style={styles.frame1}
        label="Username"
        placeholder="LoginUsing your VTOP credentials"
        mode="flat"
        placeholderTextColor="#eae8e8"
        theme={{
          fonts: { regular: { fontFamily: "Kumbh Sans", fontWeight: "Light" } },
          colors: { text: "#c3cfb7" },
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  loginFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
  },
  frame1: {
    alignSelf: "stretch",
    height: 472,
    marginTop: 79,
    overflow: "hidden",
  },
  login: {
    backgroundColor: Color.colorGray,
    flex: 1,
    width: "100%",
    height: 800,
    paddingHorizontal: 14,
    paddingVertical: 40,
  },
});

export default Login;
