import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const FrameContainer = () => {
  return (
    <View style={styles.frame}>
      <Text style={styles.bai1163}>21BAI1163</Text>
      <Image
        style={styles.frameChild}
        contentFit="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Image
        style={[styles.frameItem, styles.framePosition]}
        contentFit="cover"
        source={require("../assets/line-1.png")}
      />
      <Image
        style={[styles.frameInner, styles.framePosition]}
        contentFit="cover"
        source={require("../assets/line-2.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  framePosition: {
    height: 34,
    top: 13,
    position: "absolute",
  },
  bai1163: {
    top: 9,
    left: 72,
    fontSize: FontSize.size_xl,
    letterSpacing: 0.2,
    fontWeight: "300",
    fontFamily: FontFamily.kumbhSansLight,
    color: Color.colorLightgray,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 258,
    height: 41,
    position: "absolute",
  },
  frameChild: {
    top: 7,
    left: 11,
    width: 48,
    height: 45,
    position: "absolute",
  },
  frameItem: {
    left: 19,
    width: 30,
  },
  frameInner: {
    left: 20,
    width: 31,
  },
  frame: {
    top: 260,
    left: 0,
    borderRadius: Border.br_12xl,
    backgroundColor: Color.colorDarkslategray_100,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 1,
    width: 330,
    height: 62,
    overflow: "hidden",
    position: "absolute",
  },
});

export default FrameContainer;
