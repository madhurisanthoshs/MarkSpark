/* fonts */
export const FontFamily = {
  kumbhSansRegular: "KumbhSans-Regular",
  kumbhSansMedium: "KumbhSans-Medium",
  kumbhSansLight: "KumbhSans-Light",
  comfortaaLight: "Comfortaa-Light",
};
/* font sizes */
export const FontSize = {
  size_5xl: 24,
  size_xl: 20,
  size_base: 16,
  size_21xl: 40,
  size_13xl: 32,
};
/* Colors */
export const Color = {
  colorBlack: "#000",
  colorLightgray: "#c3cfb7",
  colorDarkslategray_100: "#35402f",
  colorDarkslategray_200: "rgba(53, 64, 47, 0.85)",
  colorDarkolivegreen: "#395922",
  colorDarkseagreen: "#b4d99a",
  colorGainsboro: "#eae8e8",
  colorWhite: "#fff",
  colorGray: "#0d0d0d",
};
/* Paddings */
export const Padding = {
  p_3xs: 10,
};
/* border radiuses */
export const Border = {
  br_12xl: 31,
  br_smi: 13,
  br_20xl: 39,
};
